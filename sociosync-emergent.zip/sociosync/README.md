# SocioSync — Local Setup (VS Code)

Smart India Hackathon 2026 · Problem Statement **26043** · Government of Jharkhand, Department of Higher & Technical Education.

A civic-tech pipeline connecting **citizens → student/faculty teams → industry/CSR partners → real-world adoption**, with AI auto-tagging and a public transparency dashboard.

## Prerequisites

| Tool | Version | Install |
|---|---|---|
| Python | 3.10+ | https://python.org |
| Node.js | 18+ | https://nodejs.org |
| Yarn | latest | `npm install -g yarn` |
| MongoDB | 6+ (local or Atlas) | https://www.mongodb.com/try/download/community |
| VS Code | latest | https://code.visualstudio.com |

Recommended VS Code extensions: **Python**, **Pylance**, **ES7+ React**, **Tailwind CSS IntelliSense**, **REST Client**.

## 1. Start MongoDB

**Option A — Local:** install MongoDB Community and run `mongod` (default `mongodb://localhost:27017`).

**Option B — MongoDB Atlas (free):** create a cluster, copy the connection string, use it as `MONGO_URL` below.

## 2. Backend (FastAPI)

Open a terminal in the project root:

```bash
cd backend
python -m venv .venv
# Windows:  .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
cp .env.example .env      # Windows PowerShell: Copy-Item .env.example .env
```

Edit `backend/.env` if your MongoDB URL differs from the default. Then start the API:

```bash
uvicorn server:app --reload --host 0.0.0.0 --port 8001
```

Backend is now live at **http://localhost:8001** and demo users + 18 seed problems are created automatically on first run.

Sanity check: open http://localhost:8001/api/ — you should see `{"service":"SocioSync API","ok":true}`.

## 3. Frontend (React)

Open a **second terminal**:

```bash
cd frontend
yarn install
cp .env.example .env      # Windows PowerShell: Copy-Item .env.example .env
yarn start
```

The app opens at **http://localhost:3000**.

> Do **not** use `npm install` — this project is Yarn-locked.

## 4. Sign in (demo accounts)

All accounts share the password `demo123`. Tap any card on the login page to auto-fill.

| Role | Email |
|---|---|
| Citizen | `citizen@sociosync.demo` |
| Student / Faculty | `student@sociosync.demo` |
| Industry / CSR partner | `industry@sociosync.demo` |
| Admin | `admin@sociosync.demo` |

Public Impact Dashboard at **/impact** works **without login**.

## 5. Jury demo flow (a few clicks)

1. Log in as **Citizen** → *Report a problem* → title *"Contaminated borewell water in Simdega"* → watch AI tag it **Water · IoT · 96% confidence** live.
2. Log out. Log in as **Student** → filter by *Water + IoT* → open the problem → **Claim** → **Start work → In Progress**.
3. Log out. Log in as **Industry Partner** → find the same problem → **Offer support** (funding + note).
4. Back as Student → **Mark Solved**. As Industry → **Mark as Adopted** with an outcome note.
5. Open **/impact** — no login — watch the funnel, drop-off, avg time-to-adoption and district charts reflect it.

## Project structure

```
sociosync/
├── backend/
│   ├── server.py           FastAPI app + all API endpoints
│   ├── ai_tagger.py        rule-based classifier (swappable to LLM)
│   ├── seed_data.py        demo users + 18 seeded problems
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.js
│   │   ├── pages/          Landing, Login, Citizen, Report, Student,
│   │   │                    Industry, Impact, Admin, ProblemDetail, About
│   │   ├── components/     Header, LifecycleStepper, AutoTagChips,
│   │   │                    ProblemCard, JourneyStrip, NotificationsBell
│   │   ├── components/ui/  shadcn primitives
│   │   ├── lib/            api client, AuthContext, constants
│   │   └── index.css       tailwind + design tokens
│   ├── package.json
│   ├── tailwind.config.js
│   └── .env.example
└── memory/
    ├── PRD.md
    └── test_credentials.md
```

## Available API endpoints (backend, all prefixed `/api`)

| Method | Path | Purpose |
|---|---|---|
| GET | `/` | Health |
| GET | `/meta` | Domains, skills, districts, statuses |
| POST | `/tag/preview` | Live auto-tag preview (domain, skill, keywords, confidence) |
| POST | `/auth/login` | Login (returns Bearer token) |
| GET | `/auth/me` | Current user |
| GET | `/auth/demo-accounts` | List of pre-seeded accounts |
| GET/POST | `/problems` | List + create |
| GET | `/problems/{id}` | Detail (includes `time_to_adoption_days`) |
| GET | `/problems/{id}/duplicates` | Same-district similarity cluster |
| POST | `/problems/{id}/claim` | Student claims |
| POST | `/problems/{id}/status` | Advance lifecycle |
| POST | `/problems/{id}/offer` | Industry offer |
| POST | `/problems/{id}/milestones` | Add milestone |
| POST | `/problems/{id}/milestones/{mid}/toggle` | Toggle done |
| POST | `/problems/{id}/retag` | Admin retag |
| DELETE | `/problems/{id}` | Admin delete |
| GET | `/impact/stats` | Public KPIs, funnel, drop-off, avg time-to-adoption |
| GET | `/notifications` | Activity feed for logged-in user |
| POST | `/admin/reseed` | Wipe + reseed demo problems (admin) |

## Troubleshooting

- **`MongoClient failed to connect`** — make sure MongoDB is running or your Atlas URL/password is correct in `backend/.env`.
- **`ECONNREFUSED` in the browser console** — the frontend can't reach the backend. Verify `REACT_APP_BACKEND_URL` in `frontend/.env` matches your backend URL (default `http://localhost:8001`) and restart `yarn start` after any `.env` change.
- **Blank page after login** — hard refresh (Cmd/Ctrl+Shift+R) once, or clear `sociosync_token` from LocalStorage.
- **Want a fresh dataset?** Log in as admin and click *Reseed demo data*, or `POST /api/admin/reseed`.

---

© 2026 SocioSync · hackathon prototype · demo data throughout.
