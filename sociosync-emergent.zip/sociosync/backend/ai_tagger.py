"""Rule-based AI auto-tagger for SocioSync.

Isolated module so it can later be swapped for an ML/LLM classifier
without touching the rest of the app. Exposes two pure functions:
  - tag_domain(problem_text) -> str
  - tag_skill_area(problem_text) -> str
"""
from __future__ import annotations
import re
from typing import Dict, List, Tuple, Any

DOMAINS: List[str] = [
    "Water", "Sanitation", "Health", "Education",
    "Agriculture", "Infrastructure", "Environment",
]

SKILLS: List[str] = [
    "IoT", "AI/ML", "Civil", "App Dev", "Mechanical", "Environmental Science",
]

# Keyword rules per domain. Higher-weight terms first.
DOMAIN_RULES: Dict[str, List[Tuple[str, int]]] = {
    "Water": [("borewell", 4), ("well", 3), ("water", 3), ("drinking water", 5), ("pipe", 2),
              ("tap", 2), ("river", 2), ("pond", 2), ("groundwater", 4), ("aquifer", 4),
              ("flood", 2), ("rain", 1)],
    "Sanitation": [("toilet", 4), ("latrine", 4), ("sewage", 5), ("drain", 3), ("garbage", 3),
                   ("waste", 3), ("dump", 2), ("sanitation", 5), ("open defecation", 5),
                   ("hygiene", 3)],
    "Health": [("hospital", 4), ("clinic", 4), ("doctor", 3), ("medicine", 3), ("disease", 4),
               ("malaria", 4), ("dengue", 4), ("anemia", 4), ("maternal", 4), ("vaccin", 4),
               ("health", 3), ("phc", 4)],
    "Education": [("school", 4), ("teacher", 3), ("student", 2), ("classroom", 4), ("dropout", 5),
                  ("literacy", 4), ("textbook", 3), ("mid-day meal", 4), ("scholarship", 3),
                  ("education", 3)],
    "Agriculture": [("farm", 4), ("crop", 4), ("irrigation", 5), ("paddy", 4), ("rice", 3),
                    ("soil", 3), ("pest", 3), ("fertilizer", 3), ("farmer", 4), ("livestock", 3),
                    ("dairy", 3), ("harvest", 3)],
    "Infrastructure": [("road", 4), ("bridge", 5), ("electric", 3), ("power", 3), ("street light", 4),
                       ("pothole", 5), ("transport", 3), ("bus", 2), ("connectivity", 3),
                       ("internet", 3), ("mobile network", 4)],
    "Environment": [("pollution", 5), ("air quality", 5), ("smog", 4), ("deforest", 5),
                    ("forest", 3), ("wildlife", 3), ("biodiversity", 4), ("plastic", 3),
                    ("mining", 3), ("emission", 4), ("climate", 3)],
}

# Skill rules
SKILL_RULES: Dict[str, List[Tuple[str, int]]] = {
    "IoT": [("sensor", 5), ("iot", 6), ("device", 3), ("monitor", 3), ("smart meter", 5),
            ("real-time", 3), ("low-cost hardware", 4), ("water level", 4), ("air quality", 4)],
    "AI/ML": [("prediction", 5), ("forecast", 4), ("machine learning", 6), ("ai ", 5),
              ("data analysis", 4), ("classification", 4), ("detect", 3), ("pattern", 3),
              ("model", 3)],
    "Civil": [("road", 4), ("bridge", 5), ("building", 3), ("construction", 4), ("drainage", 5),
              ("sewage", 4), ("pothole", 4), ("infrastructure", 3), ("concrete", 3)],
    "App Dev": [("app", 4), ("mobile", 3), ("digital platform", 5), ("website", 3), ("portal", 4),
                ("tracking system", 4), ("registration", 3), ("scholarship", 3),
                ("awareness", 3)],
    "Mechanical": [("pump", 5), ("motor", 4), ("machine", 3), ("equipment", 3), ("device", 2),
                   ("borewell", 4), ("tractor", 4), ("thresher", 4)],
    "Environmental Science": [("pollution", 5), ("biodiversity", 5), ("forest", 4),
                              ("deforest", 5), ("wildlife", 4), ("soil test", 5),
                              ("water quality", 5), ("emission", 4), ("climate", 4)],
}


def _score(text: str, rules: Dict[str, List[Tuple[str, int]]]) -> Dict[str, int]:
    t = " " + text.lower() + " "
    scores: Dict[str, int] = {k: 0 for k in rules}
    for label, kws in rules.items():
        for kw, weight in kws:
            # word-boundary match for short keywords, substring for phrases
            if " " in kw or len(kw) <= 3:
                if kw in t:
                    scores[label] += weight
            else:
                if re.search(rf"\b{re.escape(kw)}\w*", t):
                    scores[label] += weight
    return scores


def tag_domain(problem_text: str) -> str:
    scores = _score(problem_text, DOMAIN_RULES)
    best = max(scores.items(), key=lambda kv: kv[1])
    return best[0] if best[1] > 0 else "Infrastructure"


def tag_skill_area(problem_text: str) -> str:
    scores = _score(problem_text, SKILL_RULES)
    best = max(scores.items(), key=lambda kv: kv[1])
    return best[0] if best[1] > 0 else "App Dev"


def tag(problem_text: str) -> Dict[str, str]:
    return {"domain": tag_domain(problem_text), "skill": tag_skill_area(problem_text)}


def _matched_keywords(text: str, label: str, rules: Dict[str, List[Tuple[str, int]]]) -> List[str]:
    """Return unique keywords that fired for a given label."""
    t = " " + text.lower() + " "
    hits: List[str] = []
    for kw, _ in rules.get(label, []):
        if " " in kw or len(kw) <= 3:
            if kw in t and kw not in hits:
                hits.append(kw)
        else:
            if re.search(rf"\b{re.escape(kw)}\w*", t) and kw not in hits:
                hits.append(kw)
    return hits[:5]


def _confidence(scores: Dict[str, int], winner: str) -> int:
    """Confidence = winner_score / (winner_score + runner_up_score) * 100, capped 40..99."""
    top = scores.get(winner, 0)
    others = sorted([v for k, v in scores.items() if k != winner], reverse=True)
    runner = others[0] if others else 0
    if top == 0:
        return 30
    total = top + runner
    pct = int((top / total) * 100) if total else 60
    # tempered
    if pct >= 99: pct = 96
    if pct < 40: pct = 40 + (top * 3)
    return min(99, max(40, pct))


def tag_with_details(text: str) -> Dict[str, Any]:
    """Rich auto-tag: domain, skill, matched keywords for each, and confidence 0-100."""
    dom_scores = _score(text, DOMAIN_RULES)
    skl_scores = _score(text, SKILL_RULES)
    dom = max(dom_scores.items(), key=lambda kv: kv[1])
    skl = max(skl_scores.items(), key=lambda kv: kv[1])
    domain = dom[0] if dom[1] > 0 else "Infrastructure"
    skill = skl[0] if skl[1] > 0 else "App Dev"
    return {
        "domain": domain,
        "skill": skill,
        "domain_keywords": _matched_keywords(text, domain, DOMAIN_RULES),
        "skill_keywords": _matched_keywords(text, skill, SKILL_RULES),
        "domain_confidence": _confidence(dom_scores, domain),
        "skill_confidence": _confidence(skl_scores, skill),
    }
