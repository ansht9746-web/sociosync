"""SocioSync backend — FastAPI + MongoDB."""
from __future__ import annotations
from fastapi import FastAPI, APIRouter, HTTPException, Depends, Header
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone
from pathlib import Path
import os, uuid, logging, hashlib, base64, hmac, json

from ai_tagger import tag_domain, tag_skill_area, tag_with_details, DOMAINS, SKILLS
from seed_data import DEMO_USERS, DEMO_PROBLEMS, DISTRICTS

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

SECRET = os.environ.get("APP_SECRET", "sociosync-demo-secret-key")

app = FastAPI(title="SocioSync API")
api = APIRouter(prefix="/api")
log = logging.getLogger("sociosync")
logging.basicConfig(level=logging.INFO)


# ---------------------------- helpers ----------------------------
def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _hash_pw(pw: str) -> str:
    return hashlib.sha256((pw + SECRET).encode()).hexdigest()


def _sign(payload: Dict[str, Any]) -> str:
    body = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip("=")
    sig = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).hexdigest()
    return f"{body}.{sig}"


def _verify(token: str) -> Optional[Dict[str, Any]]:
    try:
        body, sig = token.split(".")
        expected = hmac.new(SECRET.encode(), body.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected):
            return None
        padded = body + "=" * (-len(body) % 4)
        return json.loads(base64.urlsafe_b64decode(padded).decode())
    except Exception:
        return None


async def current_user(authorization: Optional[str] = Header(None)) -> Dict[str, Any]:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing token")
    payload = _verify(authorization.split(" ", 1)[1])
    if not payload:
        raise HTTPException(401, "Invalid token")
    user = await db.users.find_one({"id": payload["uid"]}, {"_id": 0, "password": 0})
    if not user:
        raise HTTPException(401, "User not found")
    return user


def _clean(doc: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if doc is None:
        return None
    doc.pop("_id", None)
    return doc


def _tokens(s: str) -> set:
    import re as _re
    words = _re.findall(r"[a-zA-Z]{4,}", (s or "").lower())
    stop = {"this", "that", "with", "from", "have", "need", "will", "need",
            "problem", "issue", "very", "many", "much", "some", "also", "been"}
    return {w for w in words if w not in stop}


def _similarity(a: str, b: str) -> float:
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb: return 0.0
    return len(ta & tb) / len(ta | tb)


def _time_to_adoption_days(history: List[Dict[str, Any]]) -> Optional[int]:
    """Days between first entry and 'Adopted' entry, if adopted."""
    if not history: return None
    from datetime import datetime as _dt
    start = None
    end = None
    for h in history:
        try: t = _dt.fromisoformat(h["at"])
        except Exception: continue
        if start is None: start = t
        if h.get("status") == "Adopted": end = t
    if start and end:
        return max(0, (end - start).days)
    return None


def _enrich(p: Dict[str, Any]) -> Dict[str, Any]:
    """Attach derived fields for clients (idempotent read-time enrichment)."""
    if p is None: return p
    p["time_to_adoption_days"] = _time_to_adoption_days(p.get("history") or [])
    return p


async def _emit_event(verb: str, problem: Dict[str, Any], actor: Dict[str, Any],
                     extra: Optional[Dict[str, Any]] = None):
    subs = {problem.get("reporter")}
    if problem.get("team"):
        subs.add(problem["team"].get("lead_email"))
    for o in (problem.get("offers") or []):
        subs.add(o.get("partner"))
    subs.discard(None)
    ev = {
        "id": str(uuid.uuid4()),
        "verb": verb,
        "actor_email": actor["email"],
        "actor_name": actor["name"],
        "actor_role": actor["role"],
        "problem_id": problem["id"],
        "problem_title": problem["title"],
        "subscribers": list(subs),
        "extra": extra or {},
        "at": _now_iso(),
    }
    await db.events.insert_one(ev)


# ---------------------------- models ----------------------------
class LoginIn(BaseModel):
    email: EmailStr
    password: str


class ProblemCreate(BaseModel):
    title: str
    description: str
    district: str
    anonymous: bool = False
    image_url: Optional[str] = None


class ClaimIn(BaseModel):
    team_name: str
    org: str
    members: List[str] = []


class StatusIn(BaseModel):
    status: str  # Claimed / In Progress / Solved / Adopted
    note: Optional[str] = None
    proof_url: Optional[str] = None


class OfferIn(BaseModel):
    type: str  # funding, mentorship, equipment, pilot_site
    note: str
    amount: Optional[int] = 0


class MilestoneIn(BaseModel):
    title: str
    done: bool = False


class RetagIn(BaseModel):
    domain: Optional[str] = None
    skill: Optional[str] = None


class TagIn(BaseModel):
    text: str


VALID_STATUSES = ["Open", "Claimed", "In Progress", "Solved", "Adopted"]


# ---------------------------- routes ----------------------------
@api.get("/")
async def root():
    return {"service": "SocioSync API", "ok": True}


@api.get("/meta")
async def meta():
    return {"domains": DOMAINS, "skills": SKILLS, "districts": DISTRICTS,
            "statuses": VALID_STATUSES}


@api.post("/tag/preview")
async def tag_preview(body: TagIn):
    return tag_with_details(body.text)


# ------ auth ------
@api.post("/auth/login")
async def login(body: LoginIn):
    u = await db.users.find_one({"email": body.email.lower()})
    if not u or u.get("password") != _hash_pw(body.password):
        raise HTTPException(401, "Invalid email or password")
    token = _sign({"uid": u["id"], "role": u["role"]})
    u = _clean(u)
    u.pop("password", None)
    return {"token": token, "user": u}


@api.get("/auth/me")
async def me(user=Depends(current_user)):
    return user


@api.get("/auth/demo-accounts")
async def demo_accounts():
    """Public list of pre-seeded demo credentials (for the login screen)."""
    return [{"email": u["email"], "password": "demo123", "role": u["role"],
             "name": u["name"]} for u in DEMO_USERS]


# ------ problems ------
@api.get("/problems")
async def list_problems(status: Optional[str] = None, domain: Optional[str] = None,
                        skill: Optional[str] = None, district: Optional[str] = None,
                        reporter: Optional[str] = None):
    q: Dict[str, Any] = {}
    if status: q["status"] = status
    if domain: q["domain"] = domain
    if skill: q["skill"] = skill
    if district: q["district"] = district
    if reporter: q["reporter"] = reporter
    docs = await db.problems.find(q, {"_id": 0}).sort("created_at", -1).to_list(500)
    return docs


@api.get("/problems/{pid}")
async def get_problem(pid: str):
    p = await db.problems.find_one({"id": pid}, {"_id": 0})
    if not p:
        raise HTTPException(404, "Not found")
    return _enrich(p)


@api.get("/problems/{pid}/duplicates")
async def duplicates(pid: str, min_sim: float = 0.30):
    p = await db.problems.find_one({"id": pid}, {"_id": 0})
    if not p: raise HTTPException(404, "Not found")
    base = f"{p['title']} {p['description']}"
    others = await db.problems.find(
        {"district": p["district"], "id": {"$ne": pid}},
        {"_id": 0, "id": 1, "title": 1, "description": 1, "status": 1, "domain": 1, "skill": 1, "created_at": 1},
    ).to_list(200)
    result = []
    for o in others:
        sim = _similarity(base, f"{o['title']} {o['description']}")
        if sim >= min_sim:
            result.append({**o, "similarity": round(sim, 2)})
    result.sort(key=lambda x: x["similarity"], reverse=True)
    return result[:5]


@api.get("/notifications")
async def notifications(user=Depends(current_user)):
    q = {"subscribers": user["email"], "actor_email": {"$ne": user["email"]}}
    docs = await db.events.find(q, {"_id": 0}).sort("at", -1).limit(30).to_list(30)
    return docs


@api.post("/problems")
async def create_problem(body: ProblemCreate, user=Depends(current_user)):
    if user["role"] != "citizen":
        raise HTTPException(403, "Only citizens can report problems")
    text = f"{body.title}. {body.description}"
    tags = tag_with_details(text)
    doc = {
        "id": str(uuid.uuid4()),
        "title": body.title,
        "description": body.description,
        "district": body.district,
        "anonymous": body.anonymous,
        "image_url": body.image_url,
        "reporter": user["email"],
        "reporter_name": "Anonymous Citizen" if body.anonymous else user["name"],
        "domain": tags["domain"],
        "skill": tags["skill"],
        "domain_keywords": tags["domain_keywords"],
        "skill_keywords": tags["skill_keywords"],
        "domain_confidence": tags["domain_confidence"],
        "skill_confidence": tags["skill_confidence"],
        "status": "Open",
        "team": None,
        "milestones": [],
        "offers": [],
        "adoption_note": None,
        "proof_url": None,
        "history": [{"status": "Open", "at": _now_iso(), "note": "Reported and auto-tagged"}],
        "created_at": _now_iso(),
    }
    await db.problems.insert_one(doc.copy())
    return _clean(doc)


@api.post("/problems/{pid}/claim")
async def claim_problem(pid: str, body: ClaimIn, user=Depends(current_user)):
    if user["role"] != "student":
        raise HTTPException(403, "Only students/faculty can claim")
    p = await db.problems.find_one({"id": pid})
    if not p: raise HTTPException(404, "Not found")
    if p["status"] != "Open":
        raise HTTPException(400, "Only Open problems can be claimed")
    match_reason = (f"Skill match — team focus aligns with suggested skill area '{p.get('skill')}' "
                    f"and problem domain '{p.get('domain')}'.")
    team = {"name": body.team_name, "org": body.org,
            "members": body.members or [user["name"]],
            "lead_email": user["email"],
            "match_reason": match_reason}
    upd = {"status": "Claimed", "team": team}
    hist = p.get("history", []) + [{"status": "Claimed", "at": _now_iso(),
                                    "note": f"Claimed by {body.team_name}"}]
    await db.problems.update_one({"id": pid}, {"$set": {**upd, "history": hist}})
    await _emit_event("claimed", {**p, "team": team}, user, {"team_name": body.team_name})
    return await get_problem(pid)


@api.post("/problems/{pid}/status")
async def advance_status(pid: str, body: StatusIn, user=Depends(current_user)):
    if body.status not in VALID_STATUSES:
        raise HTTPException(400, "Invalid status")
    p = await db.problems.find_one({"id": pid})
    if not p: raise HTTPException(404, "Not found")

    role = user["role"]
    cur = p["status"]
    target = body.status
    order = VALID_STATUSES
    # role gates
    if target in {"In Progress", "Solved"} and role not in {"student", "admin"}:
        raise HTTPException(403, "Only the assigned team can advance to that stage")
    if target == "Adopted" and role not in {"industry", "admin"}:
        raise HTTPException(403, "Only industry partners or admin can mark Adopted")
    # forward-only
    if order.index(target) <= order.index(cur):
        raise HTTPException(400, f"Cannot move from {cur} to {target}")

    upd: Dict[str, Any] = {"status": target}
    if body.proof_url: upd["proof_url"] = body.proof_url
    if target == "Adopted" and body.note:
        upd["adoption_note"] = body.note
    hist = p.get("history", []) + [{"status": target, "at": _now_iso(),
                                    "note": body.note or ""}]
    await db.problems.update_one({"id": pid}, {"$set": {**upd, "history": hist}})
    await _emit_event(f"advanced_{target.lower().replace(' ', '_')}", p, user,
                      {"note": body.note or ""})
    return await get_problem(pid)


@api.post("/problems/{pid}/offer")
async def offer_support(pid: str, body: OfferIn, user=Depends(current_user)):
    if user["role"] != "industry":
        raise HTTPException(403, "Only industry partners can offer support")
    p = await db.problems.find_one({"id": pid})
    if not p: raise HTTPException(404, "Not found")
    offer = {"partner": user["email"], "partner_name": user["name"],
             "org": user.get("org", ""), "type": body.type, "note": body.note,
             "amount": body.amount or 0, "at": _now_iso()}
    await db.problems.update_one({"id": pid}, {"$push": {"offers": offer}})
    await _emit_event("offered_support", p, user,
                      {"type": body.type, "amount": body.amount or 0})
    return await get_problem(pid)


@api.post("/problems/{pid}/milestones")
async def add_milestone(pid: str, body: MilestoneIn, user=Depends(current_user)):
    if user["role"] not in {"student", "admin"}:
        raise HTTPException(403, "Only team members can add milestones")
    m = {"id": str(uuid.uuid4()), "title": body.title, "done": body.done,
         "at": _now_iso()}
    await db.problems.update_one({"id": pid}, {"$push": {"milestones": m}})
    return await get_problem(pid)


@api.post("/problems/{pid}/milestones/{mid}/toggle")
async def toggle_milestone(pid: str, mid: str, user=Depends(current_user)):
    if user["role"] not in {"student", "admin"}:
        raise HTTPException(403, "Only team members can toggle")
    p = await db.problems.find_one({"id": pid})
    if not p: raise HTTPException(404, "Not found")
    ms = p.get("milestones", [])
    for m in ms:
        if m.get("id") == mid:
            m["done"] = not m.get("done", False)
    await db.problems.update_one({"id": pid}, {"$set": {"milestones": ms}})
    return await get_problem(pid)


@api.post("/problems/{pid}/retag")
async def retag(pid: str, body: RetagIn, user=Depends(current_user)):
    if user["role"] != "admin":
        raise HTTPException(403, "Admin only")
    upd: Dict[str, Any] = {}
    if body.domain: upd["domain"] = body.domain
    if body.skill: upd["skill"] = body.skill
    if not upd: raise HTTPException(400, "Nothing to update")
    await db.problems.update_one({"id": pid}, {"$set": upd})
    return await get_problem(pid)


@api.delete("/problems/{pid}")
async def delete_problem(pid: str, user=Depends(current_user)):
    if user["role"] != "admin":
        raise HTTPException(403, "Admin only")
    res = await db.problems.delete_one({"id": pid})
    return {"deleted": res.deleted_count}


# ------ impact / public ------
@api.get("/impact/stats")
async def impact_stats():
    total = await db.problems.count_documents({})
    by_status: Dict[str, int] = {}
    for s in VALID_STATUSES:
        by_status[s] = await db.problems.count_documents({"status": s})

    pipe_domain = [{"$group": {"_id": "$domain", "count": {"$sum": 1}}}]
    by_domain = {d["_id"]: d["count"] async for d in db.problems.aggregate(pipe_domain)}

    pipe_district = [{"$group": {"_id": "$district", "count": {"$sum": 1}}}]
    by_district = {d["_id"]: d["count"] async for d in db.problems.aggregate(pipe_district)}

    # funding committed = sum of amounts on all offers
    funding = 0
    async for p in db.problems.find({}, {"offers": 1, "_id": 0}):
        for o in (p.get("offers") or []):
            funding += int(o.get("amount") or 0)

    teams = set()
    async for p in db.problems.find({"team": {"$ne": None}}, {"team": 1, "_id": 0}):
        if p.get("team"):
            teams.add(p["team"].get("name"))

    # Avg days from Open → Adopted for adopted problems
    ttl_days = []
    async for p in db.problems.find({"status": "Adopted"}, {"history": 1, "_id": 0}):
        d = _time_to_adoption_days(p.get("history") or [])
        if d is not None: ttl_days.append(d)
    avg_days = round(sum(ttl_days) / len(ttl_days), 1) if ttl_days else 0

    # Drop-off %: what fraction of Open eventually reaches each stage
    base = max(total, 1)
    drop_off = {s: round((by_status.get(s, 0) / base) * 100, 1) for s in VALID_STATUSES}

    return {
        "total": total,
        "by_status": by_status,
        "by_domain": by_domain,
        "by_district": by_district,
        "funding_committed": funding,
        "active_teams": len(teams),
        "adopted": by_status.get("Adopted", 0),
        "avg_days_to_adoption": avg_days,
        "drop_off_pct": drop_off,
    }


# ------ seed ------
async def _seed_if_empty():
    if await db.users.count_documents({}) == 0:
        for u in DEMO_USERS:
            doc = {"id": str(uuid.uuid4()), "email": u["email"].lower(),
                   "password": _hash_pw(u["password"]),
                   "role": u["role"], "name": u["name"],
                   "district": u.get("district"),
                   "org": u.get("org"), "department": u.get("department"),
                   "focus": u.get("focus"),
                   "created_at": _now_iso()}
            await db.users.insert_one(doc)
        log.info("Seeded %d users", len(DEMO_USERS))

    if await db.problems.count_documents({}) == 0:
        from datetime import timedelta
        now = datetime.now(timezone.utc)
        for p in DEMO_PROBLEMS:
            text = f"{p['title']}. {p['description']}"
            days_ago = p.get("created_at_days_ago", 0)
            created_dt = now - timedelta(days=days_ago)
            created = created_dt.isoformat()
            tags = tag_with_details(text)

            # Spread history stage timestamps across the elapsed time
            idx = VALID_STATUSES.index(p["status"])
            stage_ts = [created_dt]
            if idx > 0:
                step = timedelta(days=max(1, days_ago // max(idx, 1)))
                for i in range(1, idx + 1):
                    stage_ts.append(created_dt + step * i)
            history = [{"status": "Open", "at": stage_ts[0].isoformat(),
                        "note": "Reported and auto-tagged"}]
            for i in range(1, idx + 1):
                history.append({"status": VALID_STATUSES[i],
                                "at": stage_ts[i].isoformat(), "note": ""})

            team = p.get("team")
            if team:
                team = {**team, "lead_email": "student@sociosync.demo",
                        "match_reason": f"Skill match — team focus aligns with '{tags['skill']}' skill area."}

            doc = {
                "id": str(uuid.uuid4()),
                "title": p["title"],
                "description": p["description"],
                "district": p["district"],
                "anonymous": p.get("anonymous", False),
                "image_url": p.get("image_url"),
                "reporter": p["reporter"],
                "reporter_name": "Anonymous Citizen" if p.get("anonymous") else "Priya Kumari",
                "domain": tags["domain"],
                "skill": tags["skill"],
                "domain_keywords": tags["domain_keywords"],
                "skill_keywords": tags["skill_keywords"],
                "domain_confidence": tags["domain_confidence"],
                "skill_confidence": tags["skill_confidence"],
                "status": p["status"],
                "team": team,
                "milestones": [{"id": str(uuid.uuid4()), **m, "at": created}
                               for m in p.get("milestones", [])],
                "offers": [{**o, "partner": "industry@sociosync.demo",
                            "partner_name": "Anita Roy", "org": "Tata Steel CSR",
                            "at": created} for o in p.get("offers", [])],
                "adoption_note": p.get("adoption_note"),
                "proof_url": p.get("proof_url"),
                "history": history,
                "created_at": created,
            }
            await db.problems.insert_one(doc)
        log.info("Seeded %d problems", len(DEMO_PROBLEMS))


@api.post("/admin/reseed")
async def reseed(user=Depends(current_user)):
    if user["role"] != "admin":
        raise HTTPException(403, "Admin only")
    await db.problems.delete_many({})
    await _seed_if_empty()
    return {"ok": True}


# ---------------------------- app wiring ----------------------------
app.include_router(api)
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    await _seed_if_empty()


@app.on_event("shutdown")
async def shutdown():
    client.close()
