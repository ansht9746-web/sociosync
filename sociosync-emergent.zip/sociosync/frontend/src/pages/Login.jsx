import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast, Toaster } from "sonner";
import { useAuth } from "@/lib/AuthContext";
import { api } from "@/lib/api";
import { ROLE_HOME, ROLE_LABEL } from "@/lib/constants";
import Header from "@/components/Header";
import { LogIn, Sparkles } from "lucide-react";

export default function Login() {
  const { login, user } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [demoAccounts, setDemoAccounts] = useState([]);
  const [loading, setLoading] = useState(false);
  const nav = useNavigate();

  useEffect(() => {
    if (user) nav(ROLE_HOME[user.role], { replace: true });
    api.get("/auth/demo-accounts").then((r) => setDemoAccounts(r.data)).catch(() => {});
  }, [user, nav]);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const u = await login(email.trim().toLowerCase(), password);
      toast.success(`Welcome, ${u.name}`);
      nav(ROLE_HOME[u.role], { replace: true });
    } catch (err) {
      toast.error(err.response?.data?.detail || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const fill = (a) => { setEmail(a.email); setPassword(a.password); };

  return (
    <div className="min-h-screen bg-[hsl(var(--bg))]">
      <Header />
      <Toaster richColors position="top-center" />
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-14 grid lg:grid-cols-2 gap-10 items-start">
        <div>
          <div className="eyebrow mb-3">Sign in</div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 mb-3">
            Pick a demo role, sign in and start the flow.
          </h1>
          <p className="text-slate-600 mb-6 text-sm leading-relaxed">
            SocioSync ships with four pre-seeded accounts so the jury can walk through the full pipeline in a few clicks. Tap any card below to auto-fill.
          </p>

          <div className="space-y-3">
            {demoAccounts.map((a) => (
              <button
                key={a.email}
                onClick={() => fill(a)}
                className="w-full text-left card-surface p-4 flex items-center justify-between hover:border-emerald-700"
                data-testid={`demo-account-${a.role}`}
              >
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wider text-amber-700">{ROLE_LABEL[a.role]}</div>
                  <div className="font-display font-semibold text-slate-900">{a.name}</div>
                  <div className="text-xs text-slate-500 font-mono">{a.email} · {a.password}</div>
                </div>
                <Sparkles className="h-4 w-4 text-amber-600" />
              </button>
            ))}
          </div>
        </div>

        <div className="card-surface p-6 sm:p-8">
          <div className="flex items-center gap-2 mb-6">
            <LogIn className="h-5 w-5 text-emerald-900" />
            <h2 className="font-display text-xl font-bold text-slate-900">Sign in to SocioSync</h2>
          </div>
          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Email</label>
              <input
                type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                placeholder="citizen@sociosync.demo"
                className="w-full mt-1 rounded-xl border border-slate-200 bg-white px-4 py-2.5 focus:outline-none focus:border-emerald-700"
                data-testid="login-email"
              />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-500">Password</label>
              <input
                type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
                placeholder="demo123"
                className="w-full mt-1 rounded-xl border border-slate-200 bg-white px-4 py-2.5 focus:outline-none focus:border-emerald-700"
                data-testid="login-password"
              />
            </div>
            <button disabled={loading} className="btn-primary w-full" data-testid="login-submit">
              {loading ? "Signing in…" : "Sign in"}
            </button>
          </form>
          <p className="text-[11px] text-slate-500 mt-4">All demo credentials are public. This is a hackathon prototype — no real PII stored.</p>
        </div>
      </div>
    </div>
  );
}
