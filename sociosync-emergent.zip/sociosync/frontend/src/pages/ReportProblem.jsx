import React, { useEffect, useMemo, useState } from "react";
import Header from "@/components/Header";
import { api } from "@/lib/api";
import { useNavigate } from "react-router-dom";
import { toast, Toaster } from "sonner";
import AutoTagChips from "@/components/AutoTagChips";
import { Sparkles, MapPin } from "lucide-react";

export default function ReportProblem() {
  const [meta, setMeta] = useState({ districts: [], domains: [], skills: [] });
  const [form, setForm] = useState({ title: "", description: "", district: "Ranchi", anonymous: false, image_url: "" });
  const [preview, setPreview] = useState({ domain: "", skill: "", domain_keywords: [], skill_keywords: [], domain_confidence: 0, skill_confidence: 0 });
  const [animate, setAnimate] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const nav = useNavigate();

  useEffect(() => {
    api.get("/meta").then((r) => setMeta(r.data));
  }, []);

  const text = `${form.title}. ${form.description}`;
  useEffect(() => {
    if (text.trim().length < 6) { setPreview({ domain: "", skill: "", domain_keywords: [], skill_keywords: [], domain_confidence: 0, skill_confidence: 0 }); return; }
    const t = setTimeout(() => {
      api.post("/tag/preview", { text }).then((r) => {
        setPreview(r.data);
        setAnimate(true);
        setTimeout(() => setAnimate(false), 600);
      }).catch(() => {});
    }, 300);
    return () => clearTimeout(t);
  }, [text]);

  const canSubmit = form.title.trim().length > 4 && form.description.trim().length > 15 && form.district;

  const submit = async (e) => {
    e.preventDefault();
    if (!canSubmit) return;
    setSubmitting(true);
    try {
      const { data } = await api.post("/problems", form);
      toast.success(`Reported! Auto-tagged: ${data.domain} · ${data.skill}`);
      nav(`/problem/${data.id}`);
    } catch (err) {
      toast.error(err.response?.data?.detail || "Failed to submit");
    } finally { setSubmitting(false); }
  };

  return (
    <div className="min-h-screen">
      <Header />
      <div className="border-t-4 border-emerald-700" />
      <Toaster richColors position="top-center" />
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="eyebrow mb-2">New report</div>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900 mb-2">Describe the problem in your area.</h1>
        <p className="text-slate-600 mb-8 text-sm">We'll auto-tag domain & suggested skill area live as you type. That's how student teams find you.</p>

        <form onSubmit={submit} className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-4">
            <Field label="Title">
              <input required minLength={5} maxLength={120} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="e.g. Contaminated borewell water in Karra"
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-2.5 focus:outline-none focus:border-emerald-700"
                data-testid="report-title" />
            </Field>
            <Field label="Description">
              <textarea required minLength={20} rows={6} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Explain what's happening, since when, who is affected, and what a good solution might look like."
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 focus:outline-none focus:border-emerald-700 resize-y"
                data-testid="report-description" />
            </Field>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="District">
                <select value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })}
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-2.5 focus:outline-none focus:border-emerald-700"
                  data-testid="report-district">
                  {meta.districts.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </Field>
              <Field label="Image URL (optional)">
                <input type="url" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })}
                  placeholder="https://…"
                  className="w-full rounded-xl border border-slate-200 bg-white px-4 py-2.5 focus:outline-none focus:border-emerald-700"
                  data-testid="report-image-url" />
              </Field>
            </div>
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input type="checkbox" checked={form.anonymous} onChange={(e) => setForm({ ...form, anonymous: e.target.checked })} data-testid="report-anonymous" />
              Report anonymously
            </label>

            <button disabled={!canSubmit || submitting} type="submit" className="btn-primary" data-testid="submit-problem-btn">
              {submitting ? "Submitting…" : "Submit report"}
            </button>
          </div>

          <aside className="md:col-span-1">
            <div className="card-surface p-5 sticky top-24">
              <div className="flex items-center gap-2 text-emerald-900 mb-3">
                <Sparkles className="h-4 w-4 text-amber-600" />
                <span className="text-xs font-semibold uppercase tracking-wider">Live auto-tag preview</span>
              </div>
              {preview.domain ? (
                <>
                  <AutoTagChips domain={preview.domain} skill={preview.skill} animate={animate} />
                  <div className="mt-4 space-y-3" data-testid="tag-reasoning">
                    <ReasonRow label="Domain" value={preview.domain} confidence={preview.domain_confidence} keywords={preview.domain_keywords} />
                    <ReasonRow label="Skill" value={preview.skill} confidence={preview.skill_confidence} keywords={preview.skill_keywords} />
                  </div>
                  <p className="text-[11px] text-slate-500 mt-3 leading-relaxed">Rule-based, explainable classifier — admin can override after submission.</p>
                </>
              ) : (
                <p className="text-sm text-slate-500">Start typing a title & description — tags will appear here.</p>
              )}
              {form.image_url && (
                <div className="mt-4">
                  <img src={form.image_url} alt="Preview" className="rounded-lg border border-slate-200 max-h-40 w-full object-cover"
                    onError={(e) => (e.currentTarget.style.display = "none")} />
                </div>
              )}
              <div className="mt-4 pt-4 border-t border-slate-200 flex items-center gap-1 text-xs text-slate-500">
                <MapPin className="h-3 w-3" /> Reporting district: <b className="text-slate-800 ml-1">{form.district}</b>
              </div>
            </div>
          </aside>
        </form>
      </main>
    </div>
  );
}

function ReasonRow({ label, value, confidence, keywords }) {
  return (
    <div className="text-[11px]">
      <div className="flex items-center justify-between mb-1">
        <span className="uppercase tracking-widest font-semibold text-slate-500">{label}</span>
        <span className="font-mono font-semibold text-emerald-900">{confidence}% confidence</span>
      </div>
      <div className="h-1 bg-slate-100 rounded overflow-hidden">
        <div className="h-full bg-emerald-700" style={{ width: `${confidence}%` }} />
      </div>
      {keywords && keywords.length > 0 && (
        <div className="mt-1.5 text-slate-500">matched: <span className="font-mono text-slate-700">"{keywords.join('", "')}"</span></div>
      )}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="text-xs font-semibold uppercase tracking-wider text-slate-500 block mb-1">{label}</label>
      {children}
    </div>
  );
}
