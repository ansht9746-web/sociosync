import React, { useEffect, useMemo, useState } from "react";
import Header from "@/components/Header";
import ProblemCard from "@/components/ProblemCard";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/AuthContext";
import { Search, Filter } from "lucide-react";

export default function StudentDashboard() {
  const { user } = useAuth();
  const [meta, setMeta] = useState({ domains: [], skills: [], districts: [] });
  const [all, setAll] = useState([]);
  const [tab, setTab] = useState("open"); // open | mine
  const [f, setF] = useState({ domain: "", skill: "", district: "", q: "" });

  useEffect(() => {
    api.get("/meta").then((r) => setMeta(r.data));
    api.get("/problems").then((r) => setAll(r.data));
  }, []);

  const list = useMemo(() => {
    let items = all;
    if (tab === "open") items = items.filter((p) => p.status === "Open");
    if (tab === "mine") items = items.filter((p) => p.team && p.team.lead_email === user.email || (p.team?.members || []).includes(user.name));
    if (f.domain) items = items.filter((p) => p.domain === f.domain);
    if (f.skill) items = items.filter((p) => p.skill === f.skill);
    if (f.district) items = items.filter((p) => p.district === f.district);
    if (f.q) items = items.filter((p) => (p.title + p.description).toLowerCase().includes(f.q.toLowerCase()));
    return items;
  }, [all, tab, f, user]);

  return (
    <div className="min-h-screen">
      <Header />
      <div className="border-t-4 border-amber-500" />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="mb-6">
          <div className="eyebrow mb-2 !text-amber-700">University Innovation Hub</div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">Find a problem that matches your team's skills.</h1>
          <p className="text-slate-600 mt-1 text-sm">{user.org} · {user.department}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2 mb-6">
          <button onClick={() => setTab("open")} className={`px-4 py-1.5 rounded-full text-sm font-semibold border ${tab==="open" ? "bg-emerald-900 text-white border-emerald-900" : "bg-white text-slate-700 border-slate-200"}`} data-testid="tab-open">Open problems</button>
          <button onClick={() => setTab("mine")} className={`px-4 py-1.5 rounded-full text-sm font-semibold border ${tab==="mine" ? "bg-emerald-900 text-white border-emerald-900" : "bg-white text-slate-700 border-slate-200"}`} data-testid="tab-mine">My claimed projects</button>
          <button onClick={() => setTab("all")} className={`px-4 py-1.5 rounded-full text-sm font-semibold border ${tab==="all" ? "bg-emerald-900 text-white border-emerald-900" : "bg-white text-slate-700 border-slate-200"}`} data-testid="tab-all">All</button>
        </div>

        <div className="card-surface p-4 mb-6 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 flex-1 min-w-[220px]">
            <Search className="h-4 w-4 text-slate-500" />
            <input placeholder="Search title or description…" value={f.q} onChange={(e) => setF({...f, q: e.target.value})}
              className="w-full bg-transparent focus:outline-none text-sm" data-testid="filter-search" />
          </div>
          <FilterSelect label="Domain" value={f.domain} onChange={(v) => setF({...f, domain: v})} options={meta.domains} testid="filter-domain" />
          <FilterSelect label="Skill" value={f.skill} onChange={(v) => setF({...f, skill: v})} options={meta.skills} testid="filter-skill" />
          <FilterSelect label="District" value={f.district} onChange={(v) => setF({...f, district: v})} options={meta.districts} testid="filter-district" />
        </div>

        {list.length === 0 ? (
          <div className="card-surface p-10 text-center text-slate-500">Nothing matches your filters yet.</div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {list.map((p) => <ProblemCard key={p.id} problem={p} linkTo={`/problem/${p.id}`} />)}
          </div>
        )}
      </main>
    </div>
  );
}

function FilterSelect({ label, value, onChange, options, testid }) {
  return (
    <div className="flex items-center gap-2 border-l border-slate-200 pl-3">
      <Filter className="h-3.5 w-3.5 text-slate-400" />
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="bg-transparent text-sm focus:outline-none font-medium" data-testid={testid}>
        <option value="">{label}: All</option>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}
