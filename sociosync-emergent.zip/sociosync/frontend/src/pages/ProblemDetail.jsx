import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Header from "@/components/Header";
import LifecycleStepper, { StatusPill } from "@/components/LifecycleStepper";
import AutoTagChips from "@/components/AutoTagChips";
import JourneyStrip from "@/components/JourneyStrip";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/AuthContext";
import { toast, Toaster } from "sonner";
import { MapPin, Users, Handshake, Check, Plus, Sparkles, Building2, GraduationCap, User, AlertTriangle, Clock, Link2 } from "lucide-react";
import { Link } from "react-router-dom";

export default function ProblemDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [p, setP] = useState(null);
  const [refresh, setRefresh] = useState(0);
  const [showClaim, setShowClaim] = useState(false);
  const [showOffer, setShowOffer] = useState(false);
  const [showAdopt, setShowAdopt] = useState(false);
  const [showRetag, setShowRetag] = useState(false);
  const [msTitle, setMsTitle] = useState("");
  const [meta, setMeta] = useState({domains:[], skills:[]});
  const [dupes, setDupes] = useState([]);

  useEffect(() => {
    api.get(`/problems/${id}`).then((r) => setP(r.data)).catch(() => {});
    api.get("/meta").then((r) => setMeta(r.data));
    api.get(`/problems/${id}/duplicates`).then((r) => setDupes(r.data)).catch(() => setDupes([]));
  }, [id, refresh]);

  if (!p) return <div className="min-h-screen"><Header /><div className="p-10 text-center text-slate-500">Loading…</div></div>;

  const role = user?.role;
  const isTeamMember = p.team && (p.team.lead_email === user?.email || (p.team.members || []).includes(user?.name));
  const canClaim = role === "student" && p.status === "Open";
  const canProgress = (role === "student" && isTeamMember && p.status === "Claimed") || (role === "admin" && p.status === "Claimed");
  const canSolve = (role === "student" && isTeamMember && p.status === "In Progress") || (role === "admin" && p.status === "In Progress");
  const canOffer = role === "industry" && ["Claimed","In Progress","Solved"].includes(p.status);
  const canAdopt = (role === "industry" || role === "admin") && p.status === "Solved";
  const canRetag = role === "admin";

  const doStatus = async (status, extra = {}) => {
    try { await api.post(`/problems/${id}/status`, { status, ...extra }); toast.success(`Moved to ${status}`); setRefresh(r=>r+1); }
    catch (e) { toast.error(e.response?.data?.detail || "Failed"); }
  };
  const addMilestone = async () => {
    if (!msTitle.trim()) return;
    await api.post(`/problems/${id}/milestones`, { title: msTitle });
    setMsTitle(""); setRefresh(r=>r+1);
  };
  const toggleMs = async (mid) => { await api.post(`/problems/${id}/milestones/${mid}/toggle`); setRefresh(r=>r+1); };

  return (
    <div className="min-h-screen">
      <Header />
      <Toaster richColors position="top-center" />
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-3">
            <StatusPill status={p.status} />
            <span className="text-xs text-slate-500 inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{p.district}</span>
            <span className="text-[10px] uppercase tracking-widest text-slate-400">Demo data</span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">{p.title}</h1>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <AutoTagChips domain={p.domain} skill={p.skill} />
            {(p.domain_confidence || p.skill_confidence) && (
              <span className="text-[11px] text-slate-500" data-testid="tag-confidence">
                AI confidence: <b className="text-emerald-900">{p.domain_confidence}%</b> domain · <b className="text-emerald-900">{p.skill_confidence}%</b> skill
              </span>
            )}
            {p.time_to_adoption_days != null && (
              <span className="text-[11px] text-slate-600 inline-flex items-center gap-1" data-testid="time-to-adoption">
                <Clock className="h-3 w-3" /> {p.time_to_adoption_days} days from open to adoption
              </span>
            )}
          </div>
          {(p.domain_keywords?.length || p.skill_keywords?.length) ? (
            <div className="mt-2 text-[11px] text-slate-500">
              Matched keywords:{" "}
              <span className="font-mono text-slate-700">
                {[...(p.domain_keywords || []), ...(p.skill_keywords || [])].map((k) => `"${k}"`).join(", ")}
              </span>
            </div>
          ) : null}
        </div>

        <div className="mb-6"><JourneyStrip problem={p} /></div>

        {dupes.length > 0 && (
          <div className="mb-6 card-surface p-4 border-amber-300 bg-amber-50/60" data-testid="duplicates-panel">
            <div className="flex items-center gap-2 mb-2 text-amber-900">
              <AlertTriangle className="h-4 w-4" />
              <span className="font-semibold text-sm">Similar reports in {p.district}</span>
              <span className="text-[10px] uppercase tracking-widest text-amber-700">flagged by clustering</span>
            </div>
            <ul className="space-y-1.5">
              {dupes.map((d) => (
                <li key={d.id} className="text-sm">
                  <Link to={`/problem/${d.id}`} className="text-emerald-900 hover:underline inline-flex items-center gap-1">
                    <Link2 className="h-3 w-3" /> {d.title}
                  </Link>
                  <span className="ml-2 text-[11px] text-slate-500">· {Math.round(d.similarity * 100)}% similar · {d.status}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="card-surface p-6 mb-6">
          <LifecycleStepper current={p.status} />
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Section title="Problem description">
              <p className="text-slate-700 leading-relaxed">{p.description}</p>
              {p.image_url && <img src={p.image_url} alt="" className="mt-4 rounded-xl border border-slate-200 max-h-80 object-cover" />}
            </Section>

            <Section title="Milestones" testid="section-milestones">
              {(p.milestones || []).length === 0 && <div className="text-sm text-slate-500 mb-3">No milestones yet.</div>}
              <ul className="space-y-2">
                {(p.milestones || []).map((m) => (
                  <li key={m.id} className="flex items-center gap-3">
                    <button onClick={() => isTeamMember && toggleMs(m.id)}
                      className={`h-5 w-5 rounded border flex items-center justify-center ${m.done ? "bg-emerald-700 border-emerald-700 text-white" : "border-slate-300 bg-white"}`}
                      data-testid={`ms-toggle-${m.id}`}>
                      {m.done && <Check className="h-3 w-3" />}
                    </button>
                    <span className={`text-sm ${m.done ? "text-slate-400 line-through" : "text-slate-800"}`}>{m.title}</span>
                  </li>
                ))}
              </ul>
              {(isTeamMember || role === "admin") && (
                <div className="mt-4 flex gap-2">
                  <input value={msTitle} onChange={(e) => setMsTitle(e.target.value)} placeholder="Add a milestone…"
                    className="flex-1 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm focus:outline-none focus:border-emerald-700"
                    data-testid="ms-input" />
                  <button onClick={addMilestone} className="btn-primary !py-2 !px-4 text-sm" data-testid="ms-add"><Plus className="h-4 w-4 inline" /> Add</button>
                </div>
              )}
            </Section>

            <Section title="Timeline">
              <ol className="space-y-3">
                {(p.history || []).map((h, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="h-2 w-2 mt-2 rounded-full bg-emerald-700" />
                    <div>
                      <div className="text-sm font-semibold text-slate-800">{h.status}</div>
                      <div className="text-xs text-slate-500">{new Date(h.at).toLocaleString()}{h.note && ` · ${h.note}`}</div>
                    </div>
                  </li>
                ))}
              </ol>
            </Section>
          </div>

          <aside className="space-y-6">
            <Section title="Reporter" icon={<User className="h-4 w-4" />}>
              <div className="text-sm font-semibold text-slate-800">{p.reporter_name || (p.anonymous ? "Anonymous Citizen" : p.reporter)}</div>
              <div className="text-xs text-slate-500">{p.district}, Jharkhand</div>
            </Section>

            <Section title="Assigned team" icon={<GraduationCap className="h-4 w-4" />}>
              {p.team ? (
                <>
                  <div className="text-sm font-semibold text-slate-800">{p.team.name}</div>
                  <div className="text-xs text-slate-500 mb-2">{p.team.org}</div>
                  <div className="flex flex-wrap gap-1 mb-2">
                    {(p.team.members || []).map((m) => <span key={m} className="chip text-[10px]"><Users className="h-3 w-3" />{m}</span>)}
                  </div>
                  {p.team.match_reason && (
                    <div className="text-[11px] text-emerald-900 bg-emerald-50 border border-emerald-200 rounded-lg px-2 py-1.5 mt-2" data-testid="match-reason">
                      <b>Why this team?</b> {p.team.match_reason}
                    </div>
                  )}
                </>
              ) : <div className="text-sm text-slate-500">Not claimed yet.</div>}
              {canClaim && <button onClick={() => setShowClaim(true)} className="btn-primary mt-4 w-full text-sm" data-testid="claim-problem-btn">Claim this problem</button>}
              {canProgress && <button onClick={() => doStatus("In Progress")} className="btn-primary mt-3 w-full text-sm" data-testid="advance-lifecycle-btn">Start work → In Progress</button>}
              {canSolve && <button onClick={() => doStatus("Solved", { proof_url: "https://sociosync.demo/proof" })} className="btn-primary mt-3 w-full text-sm" data-testid="mark-solved-btn">Mark Solved</button>}
            </Section>

            <Section title="Industry partners" icon={<Building2 className="h-4 w-4" />}>
              {(p.offers || []).length === 0 && <div className="text-sm text-slate-500">No offers yet.</div>}
              <ul className="space-y-3">
                {(p.offers || []).map((o, i) => (
                  <li key={i} className="border-l-2 border-sky-500 pl-3">
                    <div className="text-sm font-semibold text-slate-800">{o.partner_name || o.partner} · <span className="text-xs font-medium text-sky-700 uppercase tracking-wider">{o.type}</span></div>
                    <div className="text-xs text-slate-500">{o.org}</div>
                    <div className="text-sm text-slate-700 mt-1">{o.note}</div>
                    {o.amount > 0 && <div className="text-xs font-semibold text-emerald-700 mt-1">₹ {o.amount.toLocaleString("en-IN")}</div>}
                  </li>
                ))}
              </ul>
              {canOffer && <button onClick={() => setShowOffer(true)} className="btn-accent w-full text-sm mt-4" data-testid="offer-support-btn"><Handshake className="h-4 w-4 inline mr-1" /> Offer support</button>}
              {canAdopt && <button onClick={() => setShowAdopt(true)} className="btn-primary w-full text-sm mt-3" data-testid="mark-adopted-btn"><Sparkles className="h-4 w-4 inline mr-1" /> Mark as Adopted</button>}
            </Section>

            {p.adoption_note && (
              <Section title="Real-world adoption" icon={<Sparkles className="h-4 w-4 text-violet-600" />}>
                <div className="text-sm text-slate-700 leading-relaxed">{p.adoption_note}</div>
              </Section>
            )}

            {canRetag && (
              <Section title="Admin">
                <button onClick={() => setShowRetag(true)} className="btn-ghost text-sm w-full" data-testid="admin-retag-btn">Re-tag domain / skill</button>
              </Section>
            )}
          </aside>
        </div>
      </main>

      {showClaim && <ClaimModal onClose={() => setShowClaim(false)} onDone={() => { setShowClaim(false); setRefresh(r=>r+1); }} pid={id} />}
      {showOffer && <OfferModal onClose={() => setShowOffer(false)} onDone={() => { setShowOffer(false); setRefresh(r=>r+1); }} pid={id} />}
      {showAdopt && <AdoptModal onClose={() => setShowAdopt(false)} onDone={() => { setShowAdopt(false); setRefresh(r=>r+1); }} pid={id} />}
      {showRetag && <RetagModal onClose={() => setShowRetag(false)} onDone={() => { setShowRetag(false); setRefresh(r=>r+1); }} pid={id} meta={meta} p={p} />}
    </div>
  );
}

function Section({ title, children, icon, testid }) {
  return (
    <section className="card-surface p-5" data-testid={testid}>
      <div className="flex items-center gap-2 mb-3">
        {icon && <span className="text-emerald-900">{icon}</span>}
        <h3 className="font-display font-semibold text-slate-900">{title}</h3>
      </div>
      {children}
    </section>
  );
}

function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-md p-6" onClick={(e) => e.stopPropagation()}>
        <h3 className="font-display text-xl font-bold text-slate-900 mb-4">{title}</h3>
        {children}
      </div>
    </div>
  );
}

function ClaimModal({ pid, onClose, onDone }) {
  const { user } = useAuth();
  const [f, setF] = useState({ team_name: "", org: user.org || "", members: user.name });
  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.post(`/problems/${pid}/claim`, { ...f, members: f.members.split(",").map((s) => s.trim()).filter(Boolean) });
      toast.success("Problem claimed!"); onDone();
    } catch (err) { toast.error(err.response?.data?.detail || "Failed"); }
  };
  return (
    <Modal title="Claim this problem" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <input required placeholder="Team name" value={f.team_name} onChange={(e) => setF({...f, team_name: e.target.value})}
          className="w-full rounded-xl border border-slate-200 px-4 py-2.5" data-testid="claim-team-name" />
        <input required placeholder="Organization / College" value={f.org} onChange={(e) => setF({...f, org: e.target.value})}
          className="w-full rounded-xl border border-slate-200 px-4 py-2.5" data-testid="claim-org" />
        <input placeholder="Members (comma separated)" value={f.members} onChange={(e) => setF({...f, members: e.target.value})}
          className="w-full rounded-xl border border-slate-200 px-4 py-2.5" data-testid="claim-members" />
        <div className="flex gap-2 justify-end pt-2">
          <button type="button" onClick={onClose} className="btn-ghost text-sm">Cancel</button>
          <button className="btn-primary text-sm" data-testid="claim-submit">Claim</button>
        </div>
      </form>
    </Modal>
  );
}
function OfferModal({ pid, onClose, onDone }) {
  const [f, setF] = useState({ type: "funding", note: "", amount: 0 });
  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.post(`/problems/${pid}/offer`, { ...f, amount: Number(f.amount) || 0 });
      toast.success("Support offer added"); onDone();
    } catch (err) { toast.error(err.response?.data?.detail || "Failed"); }
  };
  return (
    <Modal title="Offer support" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <select value={f.type} onChange={(e) => setF({...f, type: e.target.value})} className="w-full rounded-xl border border-slate-200 px-4 py-2.5" data-testid="offer-type">
          <option value="funding">Funding</option><option value="mentorship">Mentorship</option>
          <option value="equipment">Equipment</option><option value="pilot_site">Pilot site</option>
        </select>
        <textarea required placeholder="Describe your offer…" rows={3} value={f.note} onChange={(e) => setF({...f, note: e.target.value})}
          className="w-full rounded-xl border border-slate-200 px-4 py-2.5" data-testid="offer-note" />
        <input type="number" min="0" placeholder="Amount in ₹ (optional)" value={f.amount} onChange={(e) => setF({...f, amount: e.target.value})}
          className="w-full rounded-xl border border-slate-200 px-4 py-2.5" data-testid="offer-amount" />
        <div className="flex gap-2 justify-end pt-2">
          <button type="button" onClick={onClose} className="btn-ghost text-sm">Cancel</button>
          <button className="btn-accent text-sm" data-testid="offer-submit">Offer support</button>
        </div>
      </form>
    </Modal>
  );
}
function AdoptModal({ pid, onClose, onDone }) {
  const [note, setNote] = useState("");
  const submit = async (e) => {
    e.preventDefault();
    try { await api.post(`/problems/${pid}/status`, { status: "Adopted", note }); toast.success("Marked Adopted"); onDone(); }
    catch (err) { toast.error(err.response?.data?.detail || "Failed"); }
  };
  return (
    <Modal title="Mark as Adopted" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <textarea required placeholder="Real-world outcome (who adopted this, scale, dates)…" rows={4} value={note} onChange={(e) => setNote(e.target.value)}
          className="w-full rounded-xl border border-slate-200 px-4 py-2.5" data-testid="adopt-note" />
        <div className="flex gap-2 justify-end pt-2">
          <button type="button" onClick={onClose} className="btn-ghost text-sm">Cancel</button>
          <button className="btn-primary text-sm" data-testid="adopt-submit">Mark Adopted</button>
        </div>
      </form>
    </Modal>
  );
}
function RetagModal({ pid, onClose, onDone, meta, p }) {
  const [f, setF] = useState({ domain: p.domain, skill: p.skill });
  const submit = async (e) => {
    e.preventDefault();
    await api.post(`/problems/${pid}/retag`, f);
    toast.success("Retagged"); onDone();
  };
  return (
    <Modal title="Retag problem" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <select value={f.domain} onChange={(e) => setF({...f, domain: e.target.value})} className="w-full rounded-xl border border-slate-200 px-4 py-2.5" data-testid="retag-domain">
          {meta.domains.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <select value={f.skill} onChange={(e) => setF({...f, skill: e.target.value})} className="w-full rounded-xl border border-slate-200 px-4 py-2.5" data-testid="retag-skill">
          {meta.skills.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <div className="flex gap-2 justify-end pt-2">
          <button type="button" onClick={onClose} className="btn-ghost text-sm">Cancel</button>
          <button className="btn-primary text-sm" data-testid="retag-submit">Save</button>
        </div>
      </form>
    </Modal>
  );
}
