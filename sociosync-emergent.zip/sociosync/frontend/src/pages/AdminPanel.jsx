import React, { useEffect, useState } from "react";
import Header from "@/components/Header";
import { api } from "@/lib/api";
import { Link } from "react-router-dom";
import AutoTagChips from "@/components/AutoTagChips";
import { StatusPill } from "@/components/LifecycleStepper";
import { toast, Toaster } from "sonner";
import { Trash2, Tags, RefreshCw } from "lucide-react";

export default function AdminPanel() {
  const [items, setItems] = useState([]);
  const [meta, setMeta] = useState({ domains: [], skills: [] });
  const [q, setQ] = useState("");

  const refresh = () => api.get("/problems").then((r) => setItems(r.data));
  useEffect(() => { api.get("/meta").then((r) => setMeta(r.data)); refresh(); }, []);

  const del = async (id) => {
    if (!confirm("Delete this problem?")) return;
    await api.delete(`/problems/${id}`);
    toast.success("Deleted"); refresh();
  };
  const retag = async (id, domain, skill) => {
    await api.post(`/problems/${id}/retag`, { domain, skill });
    toast.success("Retagged"); refresh();
  };
  const reseed = async () => {
    if (!confirm("Wipe & reseed all problems?")) return;
    await api.post("/admin/reseed");
    toast.success("Reseeded"); refresh();
  };

  const filtered = q ? items.filter((p) => (p.title + p.description).toLowerCase().includes(q.toLowerCase())) : items;

  return (
    <div className="min-h-screen">
      <Header />
      <div className="border-t-4 border-slate-800" />
      <Toaster richColors position="top-center" />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div>
            <div className="eyebrow mb-2 !text-slate-700">Moderation</div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">Admin panel</h1>
            <p className="text-slate-600 mt-1 text-sm">Review reports, override AI tags, remove spam or duplicates.</p>
          </div>
          <button onClick={reseed} className="btn-ghost text-sm inline-flex items-center gap-2" data-testid="admin-reseed"><RefreshCw className="h-4 w-4" /> Reseed demo data</button>
        </div>

        <div className="card-surface p-4 mb-6">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search problems…"
            className="w-full bg-transparent focus:outline-none text-sm" data-testid="admin-search" />
        </div>

        <div className="card-surface overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-50 text-slate-500">
                <tr>
                  <th className="text-left px-4 py-3 font-semibold uppercase tracking-wider text-[11px]">Problem</th>
                  <th className="text-left px-4 py-3 font-semibold uppercase tracking-wider text-[11px]">Status</th>
                  <th className="text-left px-4 py-3 font-semibold uppercase tracking-wider text-[11px]">Domain</th>
                  <th className="text-left px-4 py-3 font-semibold uppercase tracking-wider text-[11px]">Skill</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p) => (
                  <tr key={p.id} className="border-t border-slate-100">
                    <td className="px-4 py-3 max-w-md">
                      <Link to={`/problem/${p.id}`} className="font-semibold text-slate-800 hover:text-emerald-900">{p.title}</Link>
                      <div className="text-xs text-slate-500 truncate">{p.district} · {p.reporter_name}</div>
                    </td>
                    <td className="px-4 py-3"><StatusPill status={p.status} /></td>
                    <td className="px-4 py-3">
                      <select value={p.domain} onChange={(e) => retag(p.id, e.target.value, p.skill)}
                        className="text-xs rounded-lg border border-slate-200 px-2 py-1" data-testid={`admin-retag-domain-${p.id}`}>
                        {meta.domains.map((d) => <option key={d} value={d}>{d}</option>)}
                      </select>
                    </td>
                    <td className="px-4 py-3">
                      <select value={p.skill} onChange={(e) => retag(p.id, p.domain, e.target.value)}
                        className="text-xs rounded-lg border border-slate-200 px-2 py-1" data-testid={`admin-retag-skill-${p.id}`}>
                        {meta.skills.map((d) => <option key={d} value={d}>{d}</option>)}
                      </select>
                    </td>
                    <td className="px-4 py-3">
                      <button onClick={() => del(p.id)} className="text-rose-600 hover:text-rose-700 inline-flex items-center gap-1 text-xs font-semibold" data-testid={`admin-delete-${p.id}`}>
                        <Trash2 className="h-3.5 w-3.5" /> Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
