import React, { useEffect, useMemo, useState } from "react";
import Header from "@/components/Header";
import ProblemCard from "@/components/ProblemCard";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/AuthContext";
import { toast, Toaster } from "sonner";
import { Handshake, Award, IndianRupee, Filter } from "lucide-react";

export default function IndustryDashboard() {
  const { user } = useAuth();
  const [all, setAll] = useState([]);
  const [meta, setMeta] = useState({ domains: [], skills: [] });
  const [tab, setTab] = useState("actionable");
  const [f, setF] = useState({ domain: "", skill: "" });

  const refresh = () => api.get("/problems").then((r) => setAll(r.data));
  useEffect(() => { api.get("/meta").then((r) => setMeta(r.data)); refresh(); }, []);

  const supported = all.filter((p) => (p.offers || []).some((o) => o.partner === user.email));
  const funding = supported.reduce((s, p) => s + (p.offers || []).filter((o) => o.partner === user.email).reduce((a, o) => a + (o.amount || 0), 0), 0);
  const adopted = supported.filter((p) => p.status === "Adopted").length;

  const list = useMemo(() => {
    let items = all;
    if (tab === "actionable") items = items.filter((p) => ["In Progress", "Solved"].includes(p.status));
    if (tab === "portfolio") items = supported;
    if (tab === "solved") items = items.filter((p) => p.status === "Solved");
    if (f.domain) items = items.filter((p) => p.domain === f.domain);
    if (f.skill) items = items.filter((p) => p.skill === f.skill);
    return items;
  }, [all, tab, f, supported]);

  return (
    <div className="min-h-screen">
      <Header />
      <div className="border-t-4 border-sky-600" />
      <Toaster richColors position="top-center" />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="mb-6">
          <div className="eyebrow mb-2 !text-sky-700">Industry & CSR Exchange</div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">Fund, mentor, or host a pilot — with real impact reporting.</h1>
          <p className="text-slate-600 mt-1 text-sm">{user.org} · Focus: {user.focus}</p>
        </div>

        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Stat icon={<Handshake className="h-5 w-5 text-sky-700" />} label="Projects supported" value={supported.length} testid="stat-supported" />
          <Stat icon={<IndianRupee className="h-5 w-5 text-emerald-700" />} label="Funding committed" value={`₹ ${funding.toLocaleString("en-IN")}`} testid="stat-funding" />
          <Stat icon={<Award className="h-5 w-5 text-violet-700" />} label="Adopted outcomes" value={adopted} testid="stat-adopted" />
        </div>

        <div className="flex flex-wrap items-center gap-2 mb-4">
          {[["actionable","Ready for support"], ["solved","Solved · pilot-ready"], ["portfolio","My portfolio"], ["all","All"]].map(([k,l]) => (
            <button key={k} onClick={() => setTab(k)} className={`px-4 py-1.5 rounded-full text-sm font-semibold border ${tab===k ? "bg-sky-700 text-white border-sky-700" : "bg-white text-slate-700 border-slate-200"}`} data-testid={`ind-tab-${k}`}>{l}</button>
          ))}
        </div>

        <div className="card-surface p-4 mb-6 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2"><Filter className="h-4 w-4 text-slate-400" />
            <select value={f.domain} onChange={(e) => setF({...f, domain: e.target.value})} className="bg-transparent text-sm focus:outline-none font-medium" data-testid="ind-filter-domain">
              <option value="">Domain: All</option>
              {meta.domains.map((d) => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
          <div className="flex items-center gap-2 border-l border-slate-200 pl-3">
            <select value={f.skill} onChange={(e) => setF({...f, skill: e.target.value})} className="bg-transparent text-sm focus:outline-none font-medium" data-testid="ind-filter-skill">
              <option value="">Skill: All</option>
              {meta.skills.map((d) => <option key={d} value={d}>{d}</option>)}
            </select>
          </div>
        </div>

        {list.length === 0 ? (
          <div className="card-surface p-10 text-center text-slate-500">Nothing here yet.</div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {list.map((p) => <ProblemCard key={p.id} problem={p} linkTo={`/problem/${p.id}`} />)}
          </div>
        )}
      </main>
    </div>
  );
}

function Stat({ icon, label, value, testid }) {
  return (
    <div className="card-surface p-5" data-testid={testid}>
      <div className="flex items-center gap-2 mb-2">{icon}<div className="text-xs uppercase tracking-widest text-slate-500 font-semibold">{label}</div></div>
      <div className="font-display text-3xl font-extrabold text-slate-900">{value}</div>
    </div>
  );
}
