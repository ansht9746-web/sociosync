import React, { useEffect, useState } from "react";
import Header from "@/components/Header";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/AuthContext";
import { Link } from "react-router-dom";
import ProblemCard from "@/components/ProblemCard";
import { Plus, FileText, Search, Filter } from "lucide-react";

export default function CitizenDashboard() {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [statusF, setStatusF] = useState("");

  useEffect(() => {
    api.get("/problems", { params: { reporter: user.email } })
      .then((r) => setItems(r.data))
      .finally(() => setLoading(false));
  }, [user.email]);

  const counts = items.reduce((a, p) => ({ ...a, [p.status]: (a[p.status] || 0) + 1 }), {});
  const filtered = items.filter((p) =>
    (!statusF || p.status === statusF) &&
    (!q || (p.title + " " + p.description).toLowerCase().includes(q.toLowerCase()))
  );

  return (
    <div className="min-h-screen">
      <Header />
      <div className="border-t-4 border-emerald-700" />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="eyebrow mb-2">Citizen Portal</div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">Hello {user.name.split(" ")[0]}, what's happening in {user.district}?</h1>
            <p className="text-slate-600 mt-1 text-sm">Report a local problem, watch it get auto-tagged, and follow it all the way to real-world adoption.</p>
          </div>
          <Link to="/citizen/report" className="btn-primary inline-flex items-center gap-2" data-testid="btn-report-problem">
            <Plus className="h-4 w-4" /> Report a problem
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
          {["Open", "Claimed", "In Progress", "Solved", "Adopted"].map((s) => (
            <div key={s} className="card-surface p-4" data-testid={`citizen-count-${s}`}>
              <div className="text-[10px] uppercase tracking-widest text-slate-500">{s}</div>
              <div className="font-display text-3xl font-extrabold text-slate-900 mt-1">{counts[s] || 0}</div>
            </div>
          ))}
        </div>

        <h2 className="font-display text-xl font-semibold text-slate-900 mb-4 flex items-center gap-2"><FileText className="h-5 w-5 text-emerald-800" /> My reported problems</h2>

        {items.length > 0 && (
          <div className="card-surface p-4 mb-5 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 flex-1 min-w-[220px]">
              <Search className="h-4 w-4 text-slate-500" />
              <input placeholder="Search my reports…" value={q} onChange={(e) => setQ(e.target.value)}
                className="w-full bg-transparent focus:outline-none text-sm" data-testid="citizen-search" />
            </div>
            <div className="flex items-center gap-2 border-l border-slate-200 pl-3">
              <Filter className="h-3.5 w-3.5 text-slate-400" />
              <select value={statusF} onChange={(e) => setStatusF(e.target.value)} className="bg-transparent text-sm focus:outline-none font-medium" data-testid="citizen-filter-status">
                <option value="">Status: All</option>
                {["Open","Claimed","In Progress","Solved","Adopted"].map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
        )}

        {loading ? <div className="text-slate-500">Loading…</div>
          : items.length === 0 ? (
            <div className="card-surface p-10 text-center">
              <p className="text-slate-600 mb-4">You haven't reported anything yet.</p>
              <Link to="/citizen/report" className="btn-primary" data-testid="empty-report-cta">Report your first problem</Link>
            </div>
          ) : filtered.length === 0 ? (
            <div className="card-surface p-10 text-center text-slate-500">Nothing matches your filters.</div>
          ) : (
            <div className="grid md:grid-cols-2 gap-5">
              {filtered.map((p) => <ProblemCard key={p.id} problem={p} linkTo={`/problem/${p.id}`} />)}
            </div>
          )}
      </main>
    </div>
  );
}
