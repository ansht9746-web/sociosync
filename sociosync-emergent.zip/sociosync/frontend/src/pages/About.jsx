import React from "react";
import Header from "@/components/Header";
import { Link } from "react-router-dom";
import { ExternalLink, ArrowRight, Award, Users, GraduationCap, Building2, ShieldCheck } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="eyebrow mb-3">About the project</div>
        <h1 className="font-display text-4xl sm:text-5xl font-extrabold text-slate-900 leading-tight mb-6">
          SocioSync — a civic-tech pipeline built for<br/>Smart India Hackathon 2026.
        </h1>

        <div className="card-surface p-6 sm:p-8 mb-8">
          <div className="grid sm:grid-cols-3 gap-6">
            <Meta label="Problem statement" value="PS 26043" />
            <Meta label="Ministry / Dept." value="Higher & Technical Education" />
            <Meta label="Government of" value="Jharkhand" />
          </div>
          <div className="border-t border-slate-200 mt-6 pt-6">
            <div className="text-xs uppercase tracking-widest text-amber-700 font-semibold mb-2">The brief</div>
            <p className="text-slate-700 leading-relaxed">
              "Build a digital platform that crowdsources societal challenges and facilitates collaborative
              problem-solving through universities and industry partnerships."
            </p>
          </div>
        </div>

        <Section title="What SocioSync actually is">
          <p>SocioSync is the <b>missing middle layer</b> between three groups that today never really connect:
          citizens with real local problems, student/faculty teams with the capacity to solve them, and industry/CSR
          partners with funding, mentorship and pilot sites to offer.</p>
          <p className="mt-3">It is explicitly <b>not</b> another complaint box and <b>not</b> another idea board. Every
          problem is meant to move through a visible, trackable path from being reported to being genuinely adopted
          in the real world.</p>
        </Section>

        <Section title="The four USPs we built to be visibly true">
          <ul className="space-y-3">
            <Bullet icon={<Users className="h-4 w-4" />}>The missing middle layer — every problem page shows citizen reporter, student team and industry partner in one horizontal strip.</Bullet>
            <Bullet icon={<Award className="h-4 w-4" />}>AI-assisted auto-tagging with visible confidence and matched keywords — not a black box.</Bullet>
            <Bullet icon={<GraduationCap className="h-4 w-4" />}>Genuinely distinct role dashboards for Citizen, Student/Faculty and Industry — different flows, not one form for all.</Bullet>
            <Bullet icon={<ShieldCheck className="h-4 w-4" />}>Public Impact & Tracker Dashboard — no login required — for state officials, media and the public.</Bullet>
          </ul>
        </Section>

        <Section title="The lifecycle we track">
          <div className="flex flex-wrap gap-2">
            {["Open", "Claimed", "In Progress", "Solved", "Adopted"].map((s) => (
              <span key={s} className="chip domain">{s}</span>
            ))}
          </div>
          <p className="mt-3">Adopted is the state-relevant milestone — the solution has been picked up for real-world civic use.</p>
        </Section>

        <Section title="Tech stack">
          <p>React 19 + Tailwind + shadcn on the frontend, FastAPI + MongoDB on the backend, Recharts for the public
          transparency dashboard, and an isolated rule-based classifier at <span className="font-mono text-sm">/backend/ai_tagger.py</span> that can
          be swapped for an LLM without touching the rest of the app.</p>
        </Section>

        <div className="flex flex-wrap gap-3 mt-8">
          <Link to="/impact" className="btn-primary inline-flex items-center gap-2">See the public tracker <ArrowRight className="h-4 w-4" /></Link>
          <Link to="/login" className="btn-ghost inline-flex items-center gap-2">Sign in with a demo role <ExternalLink className="h-4 w-4" /></Link>
        </div>
      </main>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <section className="mb-8">
      <h2 className="font-display text-xl font-bold text-slate-900 mb-3">{title}</h2>
      <div className="text-slate-700 leading-relaxed">{children}</div>
    </section>
  );
}
function Meta({ label, value }) {
  return (
    <div>
      <div className="text-[10px] font-semibold uppercase tracking-widest text-slate-500">{label}</div>
      <div className="font-display text-lg font-bold text-slate-900 mt-1">{value}</div>
    </div>
  );
}
function Bullet({ icon, children }) {
  return (
    <li className="flex items-start gap-3">
      <div className="h-7 w-7 rounded-lg bg-emerald-900/10 text-emerald-900 flex items-center justify-center shrink-0 mt-0.5">{icon}</div>
      <span className="text-slate-700">{children}</span>
    </li>
  );
}
