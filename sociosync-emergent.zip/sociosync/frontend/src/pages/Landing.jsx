import React from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import { ArrowRight, Users, Building2, GraduationCap, MapPin, Sparkles, BarChart3, ShieldCheck } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen">
      <Header />

      {/* HERO */}
      <section className="hero-glow grain relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20 lg:pt-24 lg:pb-28 relative">
          <div className="grid lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white border border-slate-200 text-xs font-semibold text-emerald-900 mb-6" data-testid="hero-badge">
                <Sparkles className="h-3.5 w-3.5 text-amber-600" />
                Government of Jharkhand · Higher & Technical Education
              </div>
              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.05]">
                The missing middle layer<br/>
                between <span className="text-emerald-900">citizens</span>, <span className="text-amber-600">universities</span> and <span className="text-sky-700">industry</span>.
              </h1>
              <p className="mt-6 text-lg text-slate-600 max-w-2xl leading-relaxed">
                SocioSync crowdsources real local problems from Jharkhand, auto-tags them with AI, matches student & faculty teams by skill, brings in CSR partners for funding and mentorship, and tracks every solution all the way to real-world adoption — publicly.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Link to="/login" className="btn-primary inline-flex items-center gap-2" data-testid="cta-report">
                  Report a problem <ArrowRight className="h-4 w-4" />
                </Link>
                <Link to="/impact" className="btn-ghost inline-flex items-center gap-2" data-testid="cta-impact">
                  See public tracker <BarChart3 className="h-4 w-4" />
                </Link>
              </div>

              <div className="mt-10 grid grid-cols-3 gap-6 max-w-lg">
                {[
                  { k: "5", v: "Lifecycle stages" },
                  { k: "7", v: "Jharkhand districts" },
                  { k: "3", v: "Roles connected" },
                ].map((s) => (
                  <div key={s.v}>
                    <div className="font-display text-3xl font-extrabold text-emerald-900">{s.k}</div>
                    <div className="text-xs uppercase tracking-widest text-slate-500 mt-1">{s.v}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: 3-role diagram */}
            <div className="lg:col-span-5">
              <div className="relative card-surface p-6 lg:p-7">
                <div className="eyebrow mb-3">The three-sided flow</div>
                <div className="space-y-3">
                  <RoleTile icon={<Users className="h-5 w-5" />} label="Citizen" text="Reports a real local problem. Auto-tagged instantly." tone="emerald" />
                  <Connector />
                  <RoleTile icon={<GraduationCap className="h-5 w-5" />} label="Student / Faculty team" text="Claims by skill match. Runs a milestone workspace." tone="amber" />
                  <Connector />
                  <RoleTile icon={<Building2 className="h-5 w-5" />} label="Industry / CSR partner" text="Offers funding, mentorship, equipment or a pilot site." tone="sky" />
                  <Connector />
                  <RoleTile icon={<ShieldCheck className="h-5 w-5" />} label="Real-world adoption" text="State officials & public track every problem — transparently." tone="violet" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* USP */}
      <section className="py-20 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-12">
            <div className="eyebrow mb-3">Why it's different</div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold text-slate-900">
              Not a complaint box. Not an idea board. A tracked pipeline.
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {USP.map((u, i) => (
              <div key={u.title} className="card-surface p-6" data-testid={`usp-card-${i}`}>
                <div className="h-9 w-9 rounded-lg bg-emerald-900/10 flex items-center justify-center text-emerald-900 mb-4">
                  <u.icon className="h-5 w-5" />
                </div>
                <h3 className="font-display font-semibold text-lg text-slate-900 mb-2">{u.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{u.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Roles CTA strip */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-6">
            <RoleCard
              accent="border-t-4 border-emerald-700"
              title="Citizens"
              copy="Report a problem in your ward. Watch it move from Open to Adopted."
              cta="Sign in as citizen"
              testid="role-cta-citizen"
            />
            <RoleCard
              accent="border-t-4 border-amber-600"
              title="Students & Faculty"
              copy="Filter open problems by your skill. Claim, build, prove — get mentored."
              cta="Sign in as student"
              testid="role-cta-student"
            />
            <RoleCard
              accent="border-t-4 border-sky-700"
              title="Industry / CSR"
              copy="Fund, mentor or host pilots. Get audit-ready CSR impact reporting."
              cta="Sign in as industry"
              testid="role-cta-industry"
            />
          </div>
        </div>
      </section>

      <footer className="border-t border-slate-200 py-10 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="h-8 w-8 rounded-lg bg-emerald-900 text-white flex items-center justify-center font-display font-bold">◈</div>
              <div>
                <div className="font-display font-bold text-slate-900">SocioSync</div>
                <div className="text-[10px] uppercase tracking-widest text-amber-700 font-semibold">SIH 2026 · PS 26043</div>
              </div>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">A civic-tech pipeline connecting citizens, universities and industry to solve Jharkhand's real problems — transparently, from reported to adopted.</p>
          </div>

          <div>
            <div className="text-[10px] uppercase tracking-widest text-slate-500 font-semibold mb-3">Problem Statement</div>
            <div className="text-sm text-slate-700 leading-relaxed">
              <b>PS 26043</b> · Government of Jharkhand<br/>
              Department of Higher & Technical Education<br/>
              Smart India Hackathon 2026
            </div>
          </div>

          <div>
            <div className="text-[10px] uppercase tracking-widest text-slate-500 font-semibold mb-3">Explore</div>
            <ul className="space-y-1.5 text-sm">
              <li><Link to="/impact" className="text-slate-700 hover:text-emerald-900">Public Impact Dashboard</Link></li>
              <li><Link to="/about" className="text-slate-700 hover:text-emerald-900">About · How it works</Link></li>
              <li><Link to="/login" className="text-slate-700 hover:text-emerald-900">Demo sign-in</Link></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8 pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div>© 2026 SocioSync · <span className="font-mono">hackathon prototype · demo data</span></div>
          <div className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" /> Ranchi · Dhanbad · Jamshedpur · Simdega · Gumla · Hazaribagh · Deoghar</div>
        </div>
      </footer>
    </div>
  );
}

const USP = [
  { title: "The missing middle layer", text: "Every problem detail page shows all three sides attached — reporter, team and partner — not just a status.", icon: Users },
  { title: "AI-assisted auto-tagging", text: "On submit, we tag Domain + Suggested Skill instantly. Manual moderation drops. Matching becomes trivial.", icon: Sparkles },
  { title: "Three-sided by design", text: "Genuinely distinct dashboards for citizens, university teams and industry — different flows, different density.", icon: GraduationCap },
  { title: "Transparent to adoption", text: "A public Impact & Tracker Dashboard, no login required — for state officials and the general public.", icon: ShieldCheck },
];

function Connector() {
  return (
    <div className="flex justify-center py-0.5">
      <div className="w-px h-4 bg-slate-300" />
    </div>
  );
}

function RoleTile({ icon, label, text, tone }) {
  const map = {
    emerald: "bg-emerald-50 text-emerald-900 border-emerald-200",
    amber: "bg-amber-50 text-amber-800 border-amber-200",
    sky: "bg-sky-50 text-sky-800 border-sky-200",
    violet: "bg-violet-50 text-violet-800 border-violet-200",
  };
  return (
    <div className={`flex items-start gap-3 p-3 rounded-xl border ${map[tone]}`}>
      <div className="h-8 w-8 rounded-lg bg-white flex items-center justify-center shadow-sm">{icon}</div>
      <div className="min-w-0">
        <div className="font-semibold text-sm">{label}</div>
        <div className="text-xs opacity-80">{text}</div>
      </div>
    </div>
  );
}

function RoleCard({ accent, title, copy, cta, testid }) {
  return (
    <div className={`card-surface p-6 ${accent}`}>
      <h3 className="font-display text-2xl font-bold text-slate-900 mb-2">{title}</h3>
      <p className="text-slate-600 text-sm leading-relaxed mb-5">{copy}</p>
      <Link to="/login" className="btn-primary inline-flex items-center gap-1.5 text-sm" data-testid={testid}>
        {cta} <ArrowRight className="h-4 w-4" />
      </Link>
    </div>
  );
}
