import React, { useEffect, useState } from "react";
import Header from "@/components/Header";
import { api } from "@/lib/api";
import { STATUSES, STATUS_CLASS } from "@/lib/constants";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, CartesianGrid, Legend } from "recharts";
import { Link } from "react-router-dom";
import { MapPin, Users, IndianRupee, Award, TrendingUp, ExternalLink, Clock } from "lucide-react";
import { StatusPill } from "@/components/LifecycleStepper";
import AutoTagChips from "@/components/AutoTagChips";

const COLORS = ["#064E3B", "#D97706", "#0284C7", "#7C3AED", "#059669", "#DC2626", "#6D28D9"];

export default function ImpactDashboard() {
  const [stats, setStats] = useState(null);
  const [problems, setProblems] = useState([]);
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    api.get("/impact/stats").then((r) => setStats(r.data));
    api.get("/problems").then((r) => setProblems(r.data));
  }, []);

  if (!stats) return <div className="min-h-screen"><Header /><div className="p-10 text-center text-slate-500">Loading impact…</div></div>;

  const funnel = STATUSES.map((s) => ({ stage: s, count: stats.by_status[s] || 0 }));
  const domainData = Object.entries(stats.by_domain).map(([name, value]) => ({ name, value }));
  const districtData = Object.entries(stats.by_district).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  const filtered = filter === "All" ? problems : problems.filter((p) => p.status === filter);

  return (
    <div className="min-h-screen">
      <Header />
      <div className="border-t-4 border-violet-700" />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="mb-8">
          <div className="eyebrow mb-2 !text-violet-700">Public transparency</div>
          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900">Impact & Tracker Dashboard</h1>
          <p className="text-slate-600 mt-2 text-sm max-w-2xl">Every problem reported through SocioSync is visible here — from the day it's opened to the day it's adopted. No login required. Meant for state officials, media and every citizen of Jharkhand.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-10">
          <Kpi label="Problems reported" value={stats.total} icon={<TrendingUp className="h-5 w-5 text-emerald-700" />} testid="kpi-total" />
          <Kpi label="Active student teams" value={stats.active_teams} icon={<Users className="h-5 w-5 text-amber-700" />} testid="kpi-teams" />
          <Kpi label="CSR funding committed" value={`₹ ${stats.funding_committed.toLocaleString("en-IN")}`} icon={<IndianRupee className="h-5 w-5 text-sky-700" />} testid="kpi-funding" />
          <Kpi label="Adopted outcomes" value={stats.adopted} icon={<Award className="h-5 w-5 text-violet-700" />} testid="kpi-adopted" />
          <Kpi label="Avg time to adoption" value={stats.avg_days_to_adoption ? `${stats.avg_days_to_adoption}d` : "—"} icon={<Clock className="h-5 w-5 text-slate-700" />} testid="kpi-time-to-adoption" />
        </div>

        <div className="card-surface p-5 mb-10" data-testid="drop-off-strip">
          <div className="text-xs font-semibold uppercase tracking-widest text-slate-500 mb-3">Pipeline drop-off — what % of reported problems reach each stage</div>
          <div className="grid grid-cols-5 gap-2">
            {STATUSES.map((s, i) => {
              const pct = stats.drop_off_pct?.[s] ?? 0;
              return (
                <div key={s} className="text-center">
                  <div className="text-[10px] uppercase tracking-widest text-slate-500">{s}</div>
                  <div className="font-display text-2xl font-extrabold text-slate-900 mt-1">{pct}%</div>
                  <div className="mt-1 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                    <div className="h-full" style={{ width: `${pct}%`, background: COLORS[i % COLORS.length] }} />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="text-[11px] text-slate-500 mt-3">A visible drop-off is honest — it shows a real pipeline, not fake numbers.</div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-10">
          <ChartCard title="Lifecycle funnel" span="lg:col-span-2" testid="chart-funnel">
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={funnel} margin={{ left: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="stage" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="count" radius={[8, 8, 0, 0]}>
                  {funnel.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="By domain" testid="chart-domain">
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={domainData} dataKey="value" nameKey="name" outerRadius={90} innerRadius={55} paddingAngle={2}>
                  {domainData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>
        </div>

        <ChartCard title="Problems by district" testid="chart-district">
          <ResponsiveContainer width="100%" height={Math.max(220, districtData.length * 42)}>
            <BarChart data={districtData} layout="vertical" margin={{ left: 30 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis type="number" tick={{ fontSize: 12 }} allowDecimals={false} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 12 }} width={90} />
              <Tooltip />
              <Bar dataKey="value" fill="#064E3B" radius={[0, 8, 8, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <div className="mt-10">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <h2 className="font-display text-2xl font-bold text-slate-900">Public problem board</h2>
            <div className="flex flex-wrap items-center gap-2">
              {["All", ...STATUSES].map((s) => (
                <button key={s} onClick={() => setFilter(s)}
                  className={`px-3 py-1 rounded-full text-xs font-semibold border ${filter === s ? "bg-emerald-900 text-white border-emerald-900" : "bg-white text-slate-700 border-slate-200"}`}
                  data-testid={`public-filter-${s}`}>{s}</button>
              ))}
            </div>
          </div>

          <div className="card-surface overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="bg-slate-50 text-slate-500">
                  <tr>
                    <th className="text-left px-4 py-3 font-semibold uppercase tracking-wider text-[11px]">Problem</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase tracking-wider text-[11px]">District</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase tracking-wider text-[11px]">Tags</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase tracking-wider text-[11px]">Status</th>
                    <th className="text-left px-4 py-3 font-semibold uppercase tracking-wider text-[11px]">Team</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((p) => (
                    <tr key={p.id} className="border-t border-slate-100" data-testid={`public-row-${p.id}`}>
                      <td className="px-4 py-3 max-w-xs">
                        <div className="font-semibold text-slate-800 truncate">{p.title}</div>
                        <div className="text-xs text-slate-500 truncate">{p.description}</div>
                      </td>
                      <td className="px-4 py-3 text-slate-700"><span className="inline-flex items-center gap-1 text-xs"><MapPin className="h-3 w-3" />{p.district}</span></td>
                      <td className="px-4 py-3"><AutoTagChips domain={p.domain} skill={p.skill} /></td>
                      <td className="px-4 py-3"><StatusPill status={p.status} /></td>
                      <td className="px-4 py-3 text-xs text-slate-600">{p.team?.name || <span className="text-slate-400">—</span>}</td>
                      <td className="px-4 py-3">
                        <Link to={`/problem/${p.id}`} className="text-emerald-800 hover:text-emerald-900 inline-flex items-center gap-1 text-xs font-semibold">
                          Journey <ExternalLink className="h-3 w-3" />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function Kpi({ label, value, icon, testid }) {
  return (
    <div className="card-surface p-5" data-testid={testid}>
      <div className="flex items-center gap-2 mb-2">{icon}<div className="text-xs uppercase tracking-widest text-slate-500 font-semibold">{label}</div></div>
      <div className="font-display text-3xl font-extrabold text-slate-900">{value}</div>
    </div>
  );
}
function ChartCard({ title, children, span = "", testid }) {
  return (
    <div className={`card-surface p-5 ${span}`} data-testid={testid}>
      <div className="text-xs font-semibold uppercase tracking-widest text-slate-500 mb-3">{title}</div>
      {children}
    </div>
  );
}
