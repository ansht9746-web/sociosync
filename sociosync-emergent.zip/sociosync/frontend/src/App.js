import React from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AuthProvider, useAuth } from "@/lib/AuthContext";
import { ROLE_HOME } from "@/lib/constants";
import Landing from "@/pages/Landing";
import Login from "@/pages/Login";
import CitizenDashboard from "@/pages/CitizenDashboard";
import ReportProblem from "@/pages/ReportProblem";
import StudentDashboard from "@/pages/StudentDashboard";
import IndustryDashboard from "@/pages/IndustryDashboard";
import ImpactDashboard from "@/pages/ImpactDashboard";
import AdminPanel from "@/pages/AdminPanel";
import ProblemDetail from "@/pages/ProblemDetail";
import About from "@/pages/About";

function Require({ roles, children }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <div className="p-10 text-center text-slate-500">Loading…</div>;
  if (!user) return <Navigate to="/login" state={{ from: loc }} replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to={ROLE_HOME[user.role]} replace />;
  return children;
}

function App() {
  return (
    <div className="App">
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/impact" element={<ImpactDashboard />} />
            <Route path="/about" element={<About />} />
            <Route path="/citizen" element={<Require roles={["citizen"]}><CitizenDashboard /></Require>} />
            <Route path="/citizen/report" element={<Require roles={["citizen"]}><ReportProblem /></Require>} />
            <Route path="/student" element={<Require roles={["student"]}><StudentDashboard /></Require>} />
            <Route path="/industry" element={<Require roles={["industry"]}><IndustryDashboard /></Require>} />
            <Route path="/admin" element={<Require roles={["admin"]}><AdminPanel /></Require>} />
            <Route path="/problem/:id" element={<Require><ProblemDetail /></Require>} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </div>
  );
}

export default App;
