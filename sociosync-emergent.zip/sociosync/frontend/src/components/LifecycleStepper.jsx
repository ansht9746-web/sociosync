import React from "react";
import { STATUSES, STATUS_CLASS } from "@/lib/constants";
import { Check } from "lucide-react";

export default function LifecycleStepper({ current, compact = false }) {
  const idx = STATUSES.indexOf(current);
  return (
    <div className={`w-full ${compact ? "" : "py-2"}`} data-testid="lifecycle-stepper">
      <ol className="flex items-center w-full gap-2">
        {STATUSES.map((s, i) => {
          const active = i === idx;
          const done = i < idx;
          const dotBase = "flex items-center justify-center rounded-full font-semibold border transition-all";
          const dot = active
            ? "bg-emerald-900 text-white border-emerald-900"
            : done
              ? "bg-emerald-100 text-emerald-800 border-emerald-300"
              : "bg-white text-slate-400 border-slate-200";
          const size = compact ? "h-6 w-6 text-[10px]" : "h-8 w-8 text-xs";
          return (
            <React.Fragment key={s}>
              <li className="flex flex-col items-center gap-1 shrink-0">
                <div className={`${dotBase} ${dot} ${size}`} data-testid={`step-${s.toLowerCase().replace(/\s/g,'-')}`}>
                  {done ? <Check className={compact ? "h-3 w-3" : "h-4 w-4"} /> : i + 1}
                </div>
                {!compact && (
                  <span className={`text-[11px] font-medium ${active ? "text-emerald-900" : done ? "text-emerald-700" : "text-slate-400"}`}>{s}</span>
                )}
              </li>
              {i < STATUSES.length - 1 && (
                <li className={`flex-1 h-[2px] rounded ${i < idx ? "bg-emerald-700" : "bg-slate-200"}`} />
              )}
            </React.Fragment>
          );
        })}
      </ol>
    </div>
  );
}

export function StatusPill({ status }) {
  const cls = STATUS_CLASS[status] || "";
  return (
    <span className={`chip ${cls}`} data-testid={`status-pill-${status.toLowerCase().replace(/\s/g,'-')}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-current" /> {status}
    </span>
  );
}
