import React from "react";
import { Link } from "react-router-dom";
import AutoTagChips from "@/components/AutoTagChips";
import LifecycleStepper, { StatusPill } from "@/components/LifecycleStepper";
import { MapPin, Users, Handshake } from "lucide-react";

export default function ProblemCard({ problem, linkTo, extra }) {
  const partners = (problem.offers || []).length;
  return (
    <Link
      to={linkTo || `/problem/${problem.id}`}
      className="card-surface p-5 block group"
      data-testid={`problem-card-${problem.id}`}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="min-w-0">
          <h3 className="font-display font-semibold text-lg leading-snug text-slate-900 group-hover:text-emerald-900 line-clamp-2">
            {problem.title}
          </h3>
          <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
            <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{problem.district}</span>
            {problem.team && <span className="inline-flex items-center gap-1"><Users className="h-3 w-3" />{problem.team.name}</span>}
            {partners > 0 && <span className="inline-flex items-center gap-1"><Handshake className="h-3 w-3" />{partners} partner{partners>1?"s":""}</span>}
          </div>
        </div>
        <StatusPill status={problem.status} />
      </div>

      <p className="text-sm text-slate-600 leading-relaxed line-clamp-2 mb-4">{problem.description}</p>

      <div className="flex items-center justify-between gap-3 mb-4">
        <AutoTagChips domain={problem.domain} skill={problem.skill} />
        <span className="text-[10px] uppercase tracking-wider text-slate-400">Demo Data</span>
      </div>

      <LifecycleStepper current={problem.status} compact />
      {extra && <div className="mt-4">{extra}</div>}
    </Link>
  );
}
