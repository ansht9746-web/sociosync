import React, { useEffect, useRef, useState } from "react";
import { Bell } from "lucide-react";
import { Link } from "react-router-dom";
import { api } from "@/lib/api";

const VERB_TEXT = {
  claimed: "claimed",
  offered_support: "offered support on",
  advanced_in_progress: "moved into In Progress on",
  advanced_solved: "marked Solved on",
  advanced_adopted: "marked Adopted on",
};

export default function NotificationsBell() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [seen, setSeen] = useState(() => Number(localStorage.getItem("ss_notifs_seen") || 0));
  const ref = useRef(null);

  const load = () => api.get("/notifications").then((r) => setItems(r.data)).catch(() => {});

  useEffect(() => {
    load();
    const t = setInterval(load, 20000);
    const onClick = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onClick);
    return () => { clearInterval(t); document.removeEventListener("mousedown", onClick); };
  }, []);

  const unread = items.filter((n) => new Date(n.at).getTime() > seen).length;
  const markSeen = () => {
    const now = Date.now();
    setSeen(now);
    localStorage.setItem("ss_notifs_seen", String(now));
  };

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => { setOpen(!open); if (!open) markSeen(); }}
        className="relative h-9 w-9 rounded-full border border-slate-200 bg-white hover:border-slate-300 flex items-center justify-center"
        data-testid="notif-bell"
      >
        <Bell className="h-4 w-4 text-slate-700" />
        {unread > 0 && (
          <span className="absolute -top-1 -right-1 h-4 min-w-4 px-1 rounded-full bg-amber-600 text-[10px] font-bold text-white flex items-center justify-center">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>
      {open && (
        <div className="absolute right-0 mt-2 w-80 max-h-[70vh] overflow-y-auto card-surface p-0 shadow-xl z-50" data-testid="notif-panel">
          <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
            <div className="font-display font-semibold text-slate-900 text-sm">Activity</div>
            <div className="text-[10px] uppercase tracking-widest text-slate-400">{items.length} recent</div>
          </div>
          {items.length === 0 ? (
            <div className="p-6 text-sm text-slate-500">Nothing yet. When a team claims your problem or a partner offers support, you'll see it here.</div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {items.map((n) => (
                <li key={n.id} className="p-3 hover:bg-slate-50">
                  <Link to={`/problem/${n.problem_id}`} onClick={() => setOpen(false)} className="block">
                    <div className="text-xs text-slate-500">
                      <span className="font-semibold text-slate-800">{n.actor_name}</span>{" "}
                      {VERB_TEXT[n.verb] || n.verb.replace(/_/g, " ")}
                    </div>
                    <div className="text-sm font-medium text-slate-900 line-clamp-2 mt-0.5">{n.problem_title}</div>
                    <div className="text-[10px] text-slate-400 mt-1">{new Date(n.at).toLocaleString()}</div>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
