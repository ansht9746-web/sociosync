import React from "react";
import { DOMAIN_ICON, SKILL_ICON } from "@/lib/constants";

export function DomainChip({ value, animate = false, testid }) {
  return (
    <span className={`chip domain ${animate ? "tag-pop" : ""}`} data-testid={testid || `chip-domain-${value}`}>
      <span>{DOMAIN_ICON[value] || "•"}</span>
      {value}
    </span>
  );
}
export function SkillChip({ value, animate = false, testid }) {
  return (
    <span className={`chip skill ${animate ? "tag-pop" : ""}`} data-testid={testid || `chip-skill-${value}`}>
      <span>{SKILL_ICON[value] || "•"}</span>
      {value}
    </span>
  );
}

export default function AutoTagChips({ domain, skill, animate = false }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {domain && <DomainChip value={domain} animate={animate} />}
      {skill && <SkillChip value={skill} animate={animate} />}
    </div>
  );
}
