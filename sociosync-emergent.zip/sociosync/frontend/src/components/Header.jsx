import React from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { ROLE_HOME, ROLE_LABEL } from "@/lib/constants";
import { LogOut, LayoutDashboard, BarChart3, Info } from "lucide-react";
import NotificationsBell from "@/components/NotificationsBell";

export default function Header() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();

  const isImpact = loc.pathname.startsWith("/impact");

  return (
    <header className="sticky top-0 z-40 bg-white/85 backdrop-blur-md border-b border-slate-200/70">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5 group" data-testid="brand-home">
          <div className="h-9 w-9 rounded-xl bg-emerald-900 text-white flex items-center justify-center font-display font-bold text-lg">
            <span>◈</span>
          </div>
          <div className="leading-tight">
            <div className="font-display font-bold text-lg tracking-tight text-slate-900">SocioSync</div>
            <div className="text-[10px] uppercase tracking-widest text-amber-700 font-semibold">SIH 2026 · PS 26043</div>
          </div>
        </Link>

        <nav className="flex items-center gap-1 sm:gap-2">
          <Link
            to="/impact"
            className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium border ${isImpact ? "border-emerald-900 text-emerald-900 bg-emerald-50" : "border-slate-200 text-slate-600 hover:border-slate-300"}`}
            data-testid="nav-impact"
          >
            <BarChart3 className="h-4 w-4" /> Public Impact
          </Link>
          <Link
            to="/about"
            className="hidden lg:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium border border-slate-200 text-slate-600 hover:border-slate-300"
            data-testid="nav-about"
          >
            <Info className="h-4 w-4" /> About
          </Link>

          {user ? (
            <>
              <NotificationsBell />
              <Link
                to={ROLE_HOME[user.role]}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium border border-slate-200 text-slate-600 hover:border-slate-300"
                data-testid="nav-dashboard"
              >
                <LayoutDashboard className="h-4 w-4" /> My Dashboard
              </Link>
              <div className="hidden md:flex items-center gap-2 pl-3 pr-2 py-1 rounded-full bg-slate-50 border border-slate-200">
                <div className="h-7 w-7 rounded-full bg-emerald-900 text-white text-xs font-semibold flex items-center justify-center">
                  {user.name?.[0] || "?"}
                </div>
                <div className="leading-tight">
                  <div className="text-xs font-semibold text-slate-800">{user.name}</div>
                  <div className="text-[10px] text-slate-500">{ROLE_LABEL[user.role]}</div>
                </div>
              </div>
              <button
                onClick={() => { logout(); nav("/"); }}
                className="btn-ghost !py-1.5 !px-3 text-sm"
                data-testid="btn-logout"
              >
                <LogOut className="h-4 w-4 inline mr-1" /> Logout
              </button>
            </>
          ) : (
            <Link to="/login" className="btn-primary !py-1.5 !px-4 text-sm" data-testid="nav-login">
              Sign in
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
