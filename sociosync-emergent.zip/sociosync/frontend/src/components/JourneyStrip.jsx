import React from "react";
import { User, GraduationCap, Building2, ShieldCheck } from "lucide-react";

/**
 * Horizontal "missing middle layer" strip:
 * Citizen → Student team → Industry partner → Adoption
 * Every side visible on one screen (SocioSync's USP #1).
 */
export default function JourneyStrip({ problem }) {
  const partners = problem.offers || [];
  const partner = partners[0];
  const adopted = problem.status === "Adopted";

  const nodes = [
    {
      role: "Citizen",
      icon: <User className="h-4 w-4" />,
      name: problem.anonymous ? "Anonymous citizen" : problem.reporter_name,
      sub: `${problem.district}, Jharkhand`,
      active: true,
      tone: "emerald",
    },
    {
      role: "Student team",
      icon: <GraduationCap className="h-4 w-4" />,
      name: problem.team ? problem.team.name : "Not claimed yet",
      sub: problem.team ? problem.team.org : "Waiting for a claim",
      active: !!problem.team,
      tone: "amber",
    },
    {
      role: "Industry partner",
      icon: <Building2 className="h-4 w-4" />,
      name: partner ? (partner.partner_name || partner.partner) : "No partner yet",
      sub: partner ? `${partner.org} · ${partner.type}` : "Awaiting CSR offer",
      active: !!partner,
      tone: "sky",
    },
    {
      role: "Adoption",
      icon: <ShieldCheck className="h-4 w-4" />,
      name: adopted ? "Adopted for real-world use" : "Pending adoption",
      sub: adopted ? "State / partner rollout" : "Not adopted yet",
      active: adopted,
      tone: "violet",
    },
  ];

  return (
    <div className="card-surface p-4 sm:p-5" data-testid="journey-strip">
      <div className="text-[10px] font-semibold uppercase tracking-widest text-amber-700 mb-3">
        The three-sided journey · all sides visible
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-stretch">
        {nodes.map((n, i) => (
          <div key={n.role} className="relative">
            <Node {...n} />
            {i < nodes.length - 1 && (
              <div className="hidden sm:block absolute top-1/2 -right-2 w-4 h-[2px] bg-slate-300" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function Node({ role, icon, name, sub, active, tone }) {
  const map = {
    emerald: active ? "border-emerald-600 bg-emerald-50 text-emerald-900" : "border-slate-200 bg-slate-50 text-slate-400",
    amber: active ? "border-amber-500 bg-amber-50 text-amber-900" : "border-dashed border-slate-300 bg-white text-slate-400",
    sky: active ? "border-sky-500 bg-sky-50 text-sky-900" : "border-dashed border-slate-300 bg-white text-slate-400",
    violet: active ? "border-violet-500 bg-violet-50 text-violet-900" : "border-dashed border-slate-300 bg-white text-slate-400",
  };
  return (
    <div className={`h-full rounded-xl border-2 p-3 ${map[tone]}`}>
      <div className="flex items-center gap-2 mb-1.5">
        <div className={`h-7 w-7 rounded-lg bg-white flex items-center justify-center shadow-sm ${active ? "" : "opacity-50"}`}>{icon}</div>
        <div className={`text-[10px] font-bold uppercase tracking-widest ${active ? "" : "text-slate-400"}`}>{role}</div>
      </div>
      <div className={`font-display font-semibold text-sm ${active ? "" : "text-slate-500"}`}>{name}</div>
      <div className="text-[11px] mt-0.5 opacity-80 truncate">{sub}</div>
    </div>
  );
}
