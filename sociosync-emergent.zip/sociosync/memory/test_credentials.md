# SocioSync — Pre-seeded Demo Accounts

All accounts share the same password: `demo123`

| Role | Email | Password | Purpose |
|------|-------|----------|---------|
| Citizen | `citizen@sociosync.demo` | `demo123` | Report problems, track own reports |
| Student/Faculty | `student@sociosync.demo` | `demo123` | Browse open problems, claim, run team workspace |
| Industry Partner | `industry@sociosync.demo` | `demo123` | Offer support, mark projects adopted |
| Admin | `admin@sociosync.demo` | `demo123` | Moderate, retag, reseed |

Login URL: `/login` — click any account chip on the login page to auto-fill.

Public Impact Dashboard `/impact` requires NO login.
