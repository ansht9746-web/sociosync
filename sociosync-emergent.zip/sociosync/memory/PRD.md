# SocioSync — Product Requirements (PRD)

## Problem statement
SIH 2026 Problem Statement 26043 (Government of Jharkhand, Department of Higher & Technical Education). Build a digital platform that crowdsources societal challenges and facilitates collaborative problem-solving through universities and industry partnerships.

## USP (all four visibly true in the product)
1. Missing middle layer — every problem shows citizen reporter, student team and industry partner on one page.
2. AI-assisted auto-tagging — rule-based classifier tags Domain + Skill live on submit.
3. Three-sided by design — genuinely distinct dashboards for Citizen / Student-Faculty / Industry.
4. Transparent to adoption — public Impact & Tracker Dashboard at /impact, no login.

## Lifecycle (single source of truth)
Open → Claimed → In Progress → Solved → Adopted

## Users
- Citizen: reports & tracks problems in their district.
- Student / Faculty team: browses open problems by domain+skill, claims, runs workspace with milestones, advances status.
- Industry / CSR partner: offers funding / mentorship / equipment / pilot site; marks Adopted.
- Admin: moderation, retag override, reseed.

## Stack
- Frontend: React 19 + Tailwind + shadcn primitives + Recharts + sonner + lucide-react
- Backend: FastAPI + Motor (MongoDB async), lightweight HMAC session tokens
- DB: MongoDB (via MONGO_URL)
- Auth: pre-seeded accounts (`citizen|student|industry|admin@sociosync.demo` / `demo123`)
- AI tagger: `/app/backend/ai_tagger.py` — swappable rule-based module

## Implemented (2026-02-11)
- Landing page with hero + three-sided flow diagram + USP grid + role CTAs
- /login with demo-account chips (tap to autofill)
- Citizen dashboard + report form with LIVE auto-tag preview + status counts + "My reports" grid
- Student dashboard: tabs (Open / Mine / All) + domain/skill/district/search filters, problem cards with tag chips + compact stepper
- Industry dashboard: KPIs (supported, funding, adopted) + tabs (actionable/solved/portfolio/all) + filters
- Public Impact Dashboard (no auth) — 4 KPIs, funnel bar, domain donut, district horizontal bar, filterable table
- Problem detail page: full LifecycleStepper, milestones with team toggle, timeline history, reporter/team/partners sidebars, all role-gated action buttons (Claim/Advance/Solved/Offer/Adopt/Retag)
- Admin panel: table with inline domain+skill retag, delete, reseed
- Seeded 18 demo problems across 7 Jharkhand districts, all 5 statuses, plus adopted outcomes

## Enhancements v2 (2026-02-11, post-first-finish, from user punch list)
- AI transparency: rule-based classifier now returns matched keywords + confidence (40-99%) shown on report form and problem detail — no longer a black box
- Journey Strip on every problem: Citizen → Student team → Industry partner → Adoption on one screen (USP #1 visibly true)
- Duplicate detection: same-district text similarity flag on problem detail (min 30% Jaccard)
- Auto-generated "why this team was matched" reason on every claim
- Time-to-adoption days computed and shown per adopted problem
- Pipeline drop-off strip on public dashboard showing % of reports reaching each stage
- Avg time-to-adoption KPI on public dashboard
- Notifications activity bell in header (polls /api/notifications every 20s) with unread badge
- Citizen dashboard: search + status filter
- Explicit /about page citing PS 26043, Higher & Technical Education, Government of Jharkhand
- Landing footer expanded with 3-column layout + district list + PS 26043 credit
- Page title, description, favicon updated to SocioSync branding

## Backend endpoints
- Auth: POST /api/auth/login, GET /api/auth/me, GET /api/auth/demo-accounts
- Meta: GET /api/meta, POST /api/tag/preview
- Problems: GET|POST /api/problems, GET /api/problems/{id}, POST /api/problems/{id}/{claim|status|offer|milestones|retag}, POST /api/problems/{id}/milestones/{mid}/toggle, DELETE /api/problems/{id}
- Impact: GET /api/impact/stats
- Admin: POST /api/admin/reseed

## Backlog (P1 next)
- P1: Real object-storage image upload (currently image URL field only)
- P1: District-level heatmap on Impact dashboard
- P1: Email/SMS notifications when a problem's status advances (Resend / Twilio)
- P2: Skill-based team suggestions engine (match teams to open problems)
- P2: LLM-powered classifier fallback for low-confidence rule matches
- P2: CSR impact PDF export for industry partners
- P2: Multi-lingual (Hindi + Nagpuri) for citizen reporting

## Test credentials
See `/app/memory/test_credentials.md`.
